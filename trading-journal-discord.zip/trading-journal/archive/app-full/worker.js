// Signal Bridge API – Cloudflare Worker + D1 + R2
// Binding cần có: DB (D1 database), HIST (R2 bucket) | Secret cần có: TOKEN
// Biến tùy chọn: KEEP_DAYS (số ngày nến/footprint mới nhất giữ lại trong D1, mặc định 7; cũ hơn thì chuyển sang R2)
//
// Dữ liệu nến M1 và footprint: lịch sử nằm trong R2 (mỗi ngày 1 file, giờ server MT5), phần mới nhất nằm trong D1 (EA ghi vào).
// /api/bars và /api/fp tự ghép hai nguồn, nếu trùng phút thì lấy bản của D1 (dữ liệu thật từ MT5).
//
// v1.11: MÃ CHUẨN (canon). Mọi biến thể tên mã của broker (XAUUSD+, XAUUSDm, XAUUSD.m, GOLD...) đều được quy về 1 khóa
//        (XAUUSD) trước khi đọc/ghi D1 và R2, nên đổi broker vẫn thấy cùng một kho dữ liệu.
//
// v1.12: AN TOÀN GIAO DỊCH. (1) Tín hiệu giao cho EA theo kiểu "nhiều nhất 1 lần" (đánh dấu 'sent' ngay lúc giao) nên 2 EA / 2 chart
//        không thể cùng vào 1 lệnh. (2) Webhook chống trùng trong 30 giây. (3) So sánh token an toàn, bắt buộc có TOKEN, tách WEBHOOK_SECRET riêng
//        (tùy chọn). (4) Cài đặt được kiểm tra/giới hạn, lệnh tay có trần lot (cfg.maxLot). (5) Lỗi bất ngờ luôn trả JSON có CORS.
//        (6) EA báo kết quả muộn vẫn ghi nhận được, nhưng không ghi đè kết quả đã chốt. (7) Giảm số truy vấn D1 mỗi giây.
//
// Lệnh tay từ web (POST /api/orders):
//   action = buy | sell                                   -> vào lệnh theo giá thị trường
//   action = buy_limit | sell_limit | buy_stop | sell_stop (kèm price) -> đặt lệnh chờ
// Sửa SL/TP vị thế từ web (kéo line trên chart): POST /api/positions/modify, web hỏi kết quả ở GET /api/modifies?id=

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type,X-Token",
};
const json = (data, status = 200) =>
  new Response(JSON.stringify(data), { status, headers: { "Content-Type": "application/json", ...CORS } });

// action của lệnh chờ -> [hướng, loại lệnh] mà EA hiểu (EA chỉ nhận action buy/sell + otype market/limit/stop)
const PENDING_ACTIONS = new Map([
  ["buy_limit", ["buy", "limit"]],
  ["sell_limit", ["sell", "limit"]],
  ["buy_stop", ["buy", "stop"]],
  ["sell_stop", ["sell", "stop"]],
]);

// So sánh chuỗi không lộ độ dài khớp (chống dò token theo thời gian phản hồi)
const safeEq = (a, b) => {
  a = String(a ?? ""); b = String(b ?? "");
  let d = a.length ^ b.length;
  const n = Math.max(a.length, b.length);
  for (let i = 0; i < n; i++) d |= (a.charCodeAt(i) || 0) ^ (b.charCodeAt(i) || 0);
  return d === 0;
};

// Giới hạn các cài đặt dạng số (ngoài khoảng thì kẹp lại, không phải số thì từ chối)
const CFG_NUM = {
  lot: [0, 100], riskPct: [0, 100], maxSpread: [0, 100000], offset: [-1e6, 1e6], rr: [0, 100], beAtR: [0, 100],
  maxTradesDay: [0, 1000], maxOpen: [0, 1000], slippage: [0, 10000], pendingMin: [0, 525600], expirySec: [0, 3600], maxLot: [0, 100],
};

let lastExpire = 0; // lần gần nhất đã dọn lệnh quá hạn (mỗi isolate), không cần dọn mỗi giây

let ready = false;
async function init(db) {
  if (ready) return;
  await db.prepare(`CREATE TABLE IF NOT EXISTS signals (
    id TEXT PRIMARY KEY, time INTEGER, action TEXT, ticker TEXT,
    entry REAL, sl REAL, tp REAL, rr REAL, oi_vol REAL,
    status TEXT, note TEXT, ticket TEXT)`).run();
  // thêm cột mới cho DB cũ (lỗi "duplicate column" khi đã có thì bỏ qua)
  for (const col of ["otype TEXT", "src TEXT", "lot REAL"]) {
    try { await db.prepare(`ALTER TABLE signals ADD COLUMN ${col}`).run(); } catch {}
  }
  await db.prepare("CREATE TABLE IF NOT EXISTS settings (k TEXT PRIMARY KEY, v TEXT)").run();
  // giá MT5 mới nhất: chỉ 1 dòng, ghi đè mỗi lần EA gửi
  await db.prepare("CREATE TABLE IF NOT EXISTS quote (k TEXT PRIMARY KEY, v TEXT, t INTEGER)").run();
  // lệnh đã đóng (1 dòng = 1 position MT5), EA đẩy lên để nhật ký giao dịch đọc
  await db.prepare(`CREATE TABLE IF NOT EXISTS trades (
    id TEXT PRIMARY KEY, account TEXT, pos TEXT, symbol TEXT, side TEXT, volume REAL,
    open_time INTEGER, close_time INTEGER, open_price REAL, close_price REAL, sl REAL, tp REAL,
    profit REAL, commission REAL, swap REAL, fee REAL, magic INTEGER, comment TEXT, reason TEXT, updated INTEGER)`).run();
  await db.prepare("CREATE INDEX IF NOT EXISTS idx_trades_close ON trades (close_time)").run();
  // journal join trades với signals theo ticket: có index thì D1 không phải quét cả bảng signals mỗi lần
  await db.prepare("CREATE INDEX IF NOT EXISTS idx_signals_ticket ON signals (ticket)").run();
  // lệnh đóng vị thế từ web gửi xuống cho EA
  await db.prepare(`CREATE TABLE IF NOT EXISTS commands (
    id TEXT PRIMARY KEY, time INTEGER, ticket TEXT, volume REAL, status TEXT, note TEXT)`).run();
  await db.prepare("CREATE INDEX IF NOT EXISTS idx_commands_status ON commands (status, time)").run();
  // lệnh sửa SL/TP vị thế từ web (kéo line trên chart) gửi xuống cho EA; sl/tp = 0 nghĩa là gỡ
  await db.prepare(`CREATE TABLE IF NOT EXISTS modifies (
    id TEXT PRIMARY KEY, time INTEGER, ticket TEXT, sl REAL, tp REAL, status TEXT, note TEXT)`).run();
  await db.prepare("CREATE INDEX IF NOT EXISTS idx_modifies_status ON modifies (status, time)").run();
  // EA hỏi pending mỗi giây: có index thì D1 không phải quét cả bảng signals mỗi lần
  await db.prepare("CREATE INDEX IF NOT EXISTS idx_signals_status ON signals (status, time)").run();
  // nến M1 cho web TPO: t = giờ server MT5 (giây), WITHOUT ROWID để mỗi nến chỉ tốn 1 lượt ghi
  await db.prepare(`CREATE TABLE IF NOT EXISTS bars (
    symbol TEXT, t INTEGER, o REAL, h REAL, l REAL, c REAL, v INTEGER,
    PRIMARY KEY (symbol, t)) WITHOUT ROWID`).run();
  // footprint: 1 dòng / phút / mã (d = JSON [[giá,mua,bán],...]) nên chỉ tốn ~1440 lượt ghi mỗi ngày
  await db.prepare(`CREATE TABLE IF NOT EXISTS fp (
    symbol TEXT, t INTEGER, d TEXT, PRIMARY KEY (symbol, t)) WITHOUT ROWID`).run();
  ready = true;
}


// ================= R2: lịch sử nến + footprint =================
// Khóa:  bars/<SYMBOL>/<YYYY-MM-DD>.txt  và  fp/<SYMBOL>/<YYYY-MM-DD>.txt  (ngày tính theo giờ server MT5)
// Mỗi dòng là 1 JSON:  bars -> [t,o,h,l,c,v]   fp -> [t,[[giá,mua,bán],...]]   (t = giờ server MT5, giây)
// Worker không parse JSON của R2, chỉ cắt dòng theo t rồi nối lại, nên rất nhẹ CPU.
const DAY = 86400;
const CAP = { bars: 10000, fp: 3000 };
const dayKey = (t) => new Date(t * 1000).toISOString().slice(0, 10);
const dayStart = (k) => Date.parse(k + "T00:00:00Z") / 1000;
const lineT = (l) => parseInt(l.slice(1), 10);
const isLine = (l) => l.charCodeAt(0) === 91 && Number.isFinite(lineT(l));
const SYM_RE = /^[A-Za-z0-9._+-]{1,24}$/; // cho phép cả mã có dấu +, ví dụ XAUUSD+

// ---------- MÃ CHUẨN ----------
// Mỗi broker đặt tên mã một kiểu (XAUUSD, XAUUSD+, XAUUSDm, XAUUSD.m, GOLD...). Dữ liệu lưu theo mã chuẩn để đổi broker vẫn dùng chung.
// Cách quy đổi (theo thứ tự):
//  1) tra bảng ALIAS (cho tên đặc biệt như GOLD, hoặc mã bạn muốn ép về tên khác)
//  2) tự bỏ hậu tố ký tự đặc biệt: XAUUSD+ / XAUUSD.m / XAUUSD# / XAUUSD_i -> XAUUSD
//  3) tự bỏ hậu tố chữ của cặp 6 ký tự: XAUUSDm / EURUSDc / EURUSDpro -> XAUUSD / EURUSD
// Mã khác (NAS100, US30, GER40, BTCUSD...) giữ nguyên, chỉ viết hoa.
const ALIAS = {
  "GOLD": "XAUUSD", "GOLDM": "XAUUSD", "XAU/USD": "XAUUSD",
  // "SILVER": "XAGUSD",
  // thêm mã đặc biệt của broker bạn vào đây
};
const canon = (s) => {
  let x = String(s || "").trim().toUpperCase();
  if (ALIAS[x]) return ALIAS[x];
  x = x.split(/[.#+_-]/)[0];                                   // bỏ mọi thứ từ ký tự đặc biệt đầu tiên
  if (ALIAS[x]) return ALIAS[x];
  const m = x.match(/^([A-Z]{6})(M|C|I|Z|PRO|RAW|ECN|STD)$/);  // cặp 6 chữ + hậu tố chữ
  return m ? m[1] : x;
};

const idxCache = new Map(); // danh sách ngày có trong R2, nhớ 60 giây để khỏi gọi list liên tục
async function r2Days(env, kind, sym) {
  if (!env.HIST) return [];
  const ck = kind + "/" + sym, c = idxCache.get(ck);
  if (c && Date.now() - c.at < 60000) return c.days;
  const days = [];
  let cursor;
  do {
    const r = await env.HIST.list({ prefix: `${kind}/${sym}/`, cursor });
    for (const o of r.objects) days.push(o.key.slice(-14, -4));
    cursor = r.truncated ? r.cursor : undefined;
  } while (cursor);
  idxCache.set(ck, { days, at: Date.now() });
  return days;
}

async function r2Lines(env, kind, sym, since, until, cap) {
  if (!env.HIST || since >= until) return [];
  const out = [];
  for (const k of await r2Days(env, kind, sym)) {
    const s = dayStart(k);
    if (s + DAY <= since || s >= until) continue;
    const o = await env.HIST.get(`${kind}/${sym}/${k}.txt`);
    if (!o) continue;
    for (const l of (await o.text()).split("\n")) {
      if (!isLine(l)) continue;
      const t = lineT(l);
      if (t >= since && t < until) { out.push(l); if (out.length >= cap) return out; }
    }
  }
  return out;
}

const rowLine = (kind) => kind === "bars"
  ? (r) => `[${r.t},${r.o},${r.h},${r.l},${r.c},${r.v}]`
  : (r) => `[${r.t},${r.d}]`;

// Gộp 2 danh sách dòng theo t; "high" thắng "low" nếu trùng t. Trả về đã sắp xếp tăng dần.
function mergeLines(low, high) {
  const m = new Map();
  for (const l of low) m.set(lineT(l), l);
  for (const l of high) m.set(lineT(l), l);
  return [...m.entries()].sort((a, b) => a[0] - b[0]).map((e) => e[1]);
}

// Đọc khoảng [since, until): D1 (mới) + R2 (lịch sử). Giới hạn cap dòng mỗi lần để web phân trang theo since như cũ.
async function readRange(env, db, kind, sym, since, until, cap) {
  const sql = kind === "bars"
    ? "SELECT t,o,h,l,c,v FROM bars WHERE symbol=? AND t>=? AND t<? ORDER BY t ASC LIMIT ?"
    : "SELECT t,d FROM fp WHERE symbol=? AND t>=? AND t<? ORDER BY t ASC LIMIT ?";
  const { results } = await db.prepare(sql).bind(sym, since, until, cap).all();
  let end = until;
  if (results.length >= cap) end = results[results.length - 1].t + 1;
  const d1 = results.map(rowLine(kind));
  const r2 = await r2Lines(env, kind, sym, since, end, cap);
  if (r2.length >= cap) end = Math.min(end, lineT(r2[r2.length - 1]) + 1);
  const lines = mergeLines(r2.filter((l) => lineT(l) < end), d1.filter((l) => lineT(l) < end));
  return lines;
}

const rawJson = (s) => new Response(s, { status: 200, headers: { "Content-Type": "application/json", ...CORS } });

// Nén dữ liệu D1 cũ hơn KEEP_DAYS sang R2 (mỗi lần chạy xử lý tối đa maxDays ngày / bảng / mã để không quá tải)
async function symbolsOf(db, tb) {
  const out = [];
  let last = "";
  for (let i = 0; i < 20; i++) {
    const r = await db.prepare(`SELECT symbol FROM ${tb} WHERE symbol > ? ORDER BY symbol LIMIT 1`).bind(last).first();
    if (!r) break;
    out.push(r.symbol); last = r.symbol;
  }
  return out;
}

async function compact(env, maxDays = 2) {
  const res = { moved: [] };
  if (!env.HIST) return { error: "chưa gắn R2 bucket HIST" };
  const db = env.DB;
  await init(db);
  const kd = env.KEEP_DAYS;
  const keep = (kd !== undefined && kd !== "" && Number(kd) >= 0 ? Number(kd) : 7) * DAY;
  for (const tb of ["bars", "fp"]) {
    for (const sym of await symbolsOf(db, tb)) {
      const mn = (await db.prepare(`SELECT MIN(t) m FROM ${tb} WHERE symbol=?`).bind(sym).first())?.m;
      const mx = (await db.prepare(`SELECT MAX(t) m FROM ${tb} WHERE symbol=?`).bind(sym).first())?.m;
      if (mn == null || mx == null) continue;
      const cutoff = Math.floor((mx - keep) / DAY) * DAY; // chỉ nén các ngày TRỌN VẸN cũ hơn mốc này
      let n = 0;
      for (let d = Math.floor(mn / DAY) * DAY; d < cutoff && n < maxDays; d += DAY) {
        const sql = tb === "bars"
          ? "SELECT t,o,h,l,c,v FROM bars WHERE symbol=? AND t>=? AND t<? ORDER BY t"
          : "SELECT t,d FROM fp WHERE symbol=? AND t>=? AND t<? ORDER BY t";
        const { results } = await db.prepare(sql).bind(sym, d, d + DAY).all();
        if (!results.length) continue;
        const key = `${tb}/${sym}/${dayKey(d)}.txt`;
        const old = await env.HIST.get(key);
        const oldLines = old ? (await old.text()).split("\n").filter(isLine) : [];
        const lines = mergeLines(oldLines, results.map(rowLine(tb))); // D1 (MT5 thật) thắng bản tải về
        await env.HIST.put(key, lines.join("\n") + "\n", { httpMetadata: { contentType: "text/plain" } });
        await db.prepare(`DELETE FROM ${tb} WHERE symbol=? AND t>=? AND t<?`).bind(sym, d, d + DAY).run();
        res.moved.push({ table: tb, symbol: sym, day: dayKey(d), rows: results.length });
        n++;
      }
    }
  }
  idxCache.clear();
  return res;
}

async function getSettings(db) {
  const r = await db.prepare("SELECT v FROM settings WHERE k='cfg'").first();
  return r ? JSON.parse(r.v) : {};
}

async function addSignal(db, s, status, note) {
  const sig = {
    id: crypto.randomUUID(), time: Date.now(), action: s.action, ticker: String(s.ticker || ""),
    entry: Number(s.entry), sl: Number(s.sl), tp: Number(s.tp),
    rr: Number(s.rr) || null, oi_vol: Number(s.oi_vol) || null, status, note: note || "", ticket: "",
    otype: ["market", "limit", "stop"].includes(s.otype) ? s.otype : "market",
    src: s.src === "manual" ? "manual" : "tv",
    lot: Number(s.lot) > 0 ? Number(s.lot) : null,
  };
  await db.prepare(`INSERT INTO signals (id,time,action,ticker,entry,sl,tp,rr,oi_vol,status,note,ticket,otype,src,lot)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
    .bind(sig.id, sig.time, sig.action, sig.ticker, sig.entry, sig.sl, sig.tp, sig.rr, sig.oi_vol, sig.status, sig.note, sig.ticket, sig.otype, sig.src, sig.lot)
    .run();
  return sig;
}

function validSignal(s) {
  return s && (s.action === "buy" || s.action === "sell") &&
    [s.entry, s.sl, s.tp].every((x) => Number.isFinite(Number(x)) && Number(x) > 0);
}

// Tín hiệu + lệnh đóng + lệnh sửa SL/TP đang chờ EA + cài đặt (dùng cho cả /api/ea/pending và /api/ea/sync)
// Thứ tự khóa (settings, signals, commands, modifies) QUAN TRỌNG: EA tách chuỗi JSON theo đúng thứ tự này.
async function pendingPayload(db) {
  const cfg = await getSettings(db);
  const ttl = (Number(cfg.expirySec) || 60) * 1000;
  const now = Date.now();
  const cut = now - ttl;
  if (now - lastExpire > 5000) {                       // dọn quá hạn tối đa 5 giây/lần (trước đây mỗi giây 3 truy vấn ghi)
    lastExpire = now;
    await db.prepare("UPDATE signals SET status='expired', note='Quá hạn, EA không kịp nhận' WHERE status='pending' AND time < ?").bind(cut).run();
    await db.prepare("UPDATE commands SET status='expired', note='Quá hạn, EA không kịp nhận' WHERE status='pending' AND time < ?").bind(cut).run();
    await db.prepare("UPDATE modifies SET status='expired', note='Quá hạn, EA không kịp nhận' WHERE status='pending' AND time < ?").bind(cut).run();
  }
  // Tín hiệu: GIAO NGAY 1 LẦN. Đánh dấu 'sent' và lấy về trong cùng 1 câu lệnh nguyên tử, nên dù có 2 EA hỏi cùng lúc cũng chỉ 1 EA nhận được.
  // (Nếu phản hồi bị rớt giữa đường thì lệnh bị bỏ lỡ chứ không bao giờ vào đôi. Web sẽ báo "chưa có phản hồi".)
  const sg = await db.prepare("UPDATE signals SET status='sent' WHERE status='pending' AND time >= ? RETURNING *").bind(cut).all();
  const signals = (sg.results || []).sort((a, b) => a.time - b.time);
  const cm = await db.prepare("SELECT * FROM commands WHERE status='pending' AND time >= ? ORDER BY time ASC").bind(cut).all();
  const md = await db.prepare("SELECT * FROM modifies WHERE status='pending' AND time >= ? ORDER BY time ASC").bind(cut).all();
  return { settings: cfg, signals, commands: cm.results, modifies: md.results };
}

async function handle(req, env) {
    if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: CORS });
    const db = env.DB;
    const url = new URL(req.url);
    const path = url.pathname;
    const m = req.method;
    if (!env.TOKEN) return json({ error: "Worker chưa cài secret TOKEN" }, 500);   // thiếu TOKEN thì từ chối hết, tránh mở toang
    await init(db);

    // ---- TradingView webhook (không gửi được header, nên secret nằm trong body) ----
    if (path === "/webhook/tradingview" && m === "POST") {
      let body;
      try { body = JSON.parse(await req.text()); } catch { return json({ error: "JSON không hợp lệ" }, 400); }
      if (!safeEq(body.secret, env.WEBHOOK_SECRET || env.TOKEN)) return json({ error: "sai secret" }, 401);   // có WEBHOOK_SECRET thì chỉ nhận secret đó, TOKEN của web/EA không dùng được cho webhook
      if (!validSignal(body)) return json({ error: "thiếu action/entry/sl/tp" }, 400);

      const cfg = await getSettings(db);
      let status = "pending", note = "";
      if (!cfg.enabled) { status = "rejected"; note = "Công tắc 'Cho phép EA vào lệnh' đang tắt"; }
      else if (body.action === "buy" && cfg.allowLong === false) { status = "rejected"; note = "LONG đang bị tắt"; }
      else if (body.action === "sell" && cfg.allowShort === false) { status = "rejected"; note = "SHORT đang bị tắt"; }

      if (status === "pending") {   // TradingView có thể gửi lại cùng 1 alert: bỏ bản trùng trong 30 giây
        const dup = await db.prepare("SELECT id FROM signals WHERE src='tv' AND action=? AND ticker=? AND entry=? AND sl=? AND tp=? AND time>? LIMIT 1")
          .bind(body.action, String(body.ticker || ""), Number(body.entry), Number(body.sl), Number(body.tp), Date.now() - 30000).first();
        if (dup) { status = "rejected"; note = "Tín hiệu trùng (đã nhận trong 30 giây trước)"; }
      }
      body.src = "tv"; body.otype = "market"; // tín hiệu từ TradingView luôn là market, quy đổi theo khoảng cách
      const sig = await addSignal(db, body, status, note);
      return json({ ok: true, id: sig.id, status });
    }

    // ---- Các endpoint còn lại cần header X-Token ----
    if (!safeEq(req.headers.get("X-Token"), env.TOKEN)) return json({ error: "unauthorized" }, 401);

    if (path === "/api/health" && m === "GET") return json({ ok: true });

    if (path === "/api/settings") {
      if (m === "GET") return json(await getSettings(db));
      if (m === "PUT") {
        const cfg = await req.json();
        if (!cfg || typeof cfg !== "object" || Array.isArray(cfg)) return json({ error: "dữ liệu không hợp lệ" }, 400);
        delete cfg.token; delete cfg.apiUrl; // không lưu bí mật lên DB
        for (const k in CFG_NUM) {
          if (cfg[k] === undefined || cfg[k] === null || cfg[k] === "") continue;
          const n = Number(cfg[k]);
          if (!Number.isFinite(n)) return json({ error: "cài đặt không hợp lệ: " + k }, 400);
          cfg[k] = Math.min(CFG_NUM[k][1], Math.max(CFG_NUM[k][0], n));
        }
        if (JSON.stringify(cfg).length > 20000) return json({ error: "cài đặt quá lớn" }, 413);
        await db.prepare("INSERT INTO settings (k,v) VALUES ('cfg',?) ON CONFLICT(k) DO UPDATE SET v=excluded.v")
          .bind(JSON.stringify(cfg)).run();
        return json({ ok: true });
      }
    }

    if (path === "/api/signals") {
      if (m === "GET") {
        const { results } = await db.prepare("SELECT * FROM signals ORDER BY time DESC LIMIT 100").all();
        return json(results);
      }
      if (m === "DELETE") {
        await db.prepare("DELETE FROM signals").run();
        return json({ ok: true });
      }
    }

    if (path === "/api/signals/test" && m === "POST") {
      const body = await req.json();
      if (!validSignal(body)) return json({ error: "tín hiệu không hợp lệ" }, 400);
      return json(await addSignal(db, body, "pending", "Tín hiệu thử"));
    }

    // ---- Lệnh tay từ web ----
    // action = buy | sell: vào lệnh theo giá thị trường.
    // action = buy_limit | sell_limit | buy_stop | sell_stop: lệnh chờ, bắt buộc có price (giá MT5, EA không quy đổi).
    // SL/TP không bắt buộc (bỏ trống hoặc 0 = không đặt). Việc kiểm tra giá nằm đúng phía so với thị trường do EA làm vì chỉ EA có bid/ask thật.
    // LƯU Ý: ticker của lệnh tay là mã MT5 thật của broker, KHÔNG đưa qua canon().
    if (path === "/api/orders" && m === "POST") {
      const b = await req.json().catch(() => null);
      const pa = b ? PENDING_ACTIONS.get(b.action) : null;
      const side = pa ? pa[0] : b && b.action;
      if (!b || (side !== "buy" && side !== "sell")) return json({ error: "hướng lệnh không hợp lệ" }, 400);
      const otype = pa ? pa[1] : "market";
      const price = Number(b.price) || 0;
      const ticker = String(b.ticker || "").trim();
      const lot = Number(b.lot), sl = Number(b.sl) || 0, tp = Number(b.tp) || 0;
      if (pa && !(price > 0)) return json({ error: "thiếu giá đặt lệnh chờ" }, 400);
      if (!ticker) return json({ error: "thiếu mã giao dịch" }, 400);
      if (!Number.isFinite(lot) || lot <= 0 || lot > 100) return json({ error: "lot không hợp lệ" }, 400);
      if (sl < 0 || tp < 0) return json({ error: "SL/TP không hợp lệ" }, 400);

      const cfg = await getSettings(db);
      if (Number(cfg.maxLot) > 0 && lot > Number(cfg.maxLot)) return json({ error: "lot vượt mức tối đa cho phép (maxLot)" }, 400);
      let status = "pending", note = "";
      if (!cfg.enabled) { status = "rejected"; note = "Công tắc 'Cho phép EA vào lệnh' đang tắt"; }
      else if (side === "buy" && cfg.allowLong === false) { status = "rejected"; note = "LONG đang bị tắt"; }
      else if (side === "sell" && cfg.allowShort === false) { status = "rejected"; note = "SHORT đang bị tắt"; }

      const sig = await addSignal(db, { action: side, ticker, entry: pa ? price : 0, sl, tp, lot, otype, src: "manual" }, status, note);
      return json({ ok: true, id: sig.id, status, note });
    }

    // Web hỏi kết quả của lệnh tay vừa gửi (EA báo lại qua /api/ea/report)
    if (path === "/api/orders" && m === "GET") {
      const r = await db.prepare("SELECT id,status,note,ticket FROM signals WHERE id=?").bind(url.searchParams.get("id") || "").first();
      return r ? json(r) : json({ error: "not found" }, 404);
    }

    // ---- Giá MT5: web đọc ----
    if (path === "/api/quote" && m === "GET") {
      const r = await db.prepare("SELECT v, t FROM quote WHERE k='latest'").first();
      if (!r) return json({ quotes: [], account: null, receivedAt: 0 });
      const q = JSON.parse(r.v);
      q.receivedAt = r.t; // giờ server Cloudflare lúc nhận
      return json(q);
    }

    // ---- EA MT5 ----
    if (path === "/api/ea/quote" && m === "POST") {
      const b = await req.json(); // { quotes:[{ticker,symbol,bid,ask,spread,tickTime}], account:{...}, serverTime }
      if (!Array.isArray(b.quotes)) return json({ error: "thiếu quotes" }, 400);
      if (JSON.stringify(b).length > 400000) return json({ error: "dữ liệu không hợp lệ" }, 413);
      await db.prepare("INSERT INTO quote (k,v,t) VALUES ('latest',?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v, t=excluded.t")
        .bind(JSON.stringify(b), Date.now()).run();
      return json({ ok: true });
    }

    if (path === "/api/ea/pending" && m === "GET") return json(await pendingPayload(db));

    // EA gửi giá/vị thế và nhận luôn tín hiệu + lệnh đóng + lệnh sửa SL/TP trong CÙNG 1 request (giảm một nửa số request).
    if (path === "/api/ea/sync" && m === "POST") {
      const b = await req.json();
      if (!Array.isArray(b.quotes)) return json({ error: "thiếu quotes" }, 400);
      if (JSON.stringify(b).length > 400000) return json({ error: "dữ liệu không hợp lệ" }, 413);
      const now = Date.now();
      await db.prepare("INSERT INTO quote (k,v,t) VALUES ('latest',?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v, t=excluded.t")
        .bind(JSON.stringify(b), now).run();
      return json(await pendingPayload(db));
    }

    if (path === "/api/ea/report" && m === "POST") {
      const b = await req.json(); // { id, status: "executed"|"placed"|"rejected", ticket, note }
      if (!["executed", "placed", "rejected"].includes(b.status)) return json({ error: "status sai" }, 400);
      // Chỉ ghi khi lệnh chưa có kết quả chốt: báo muộn (đã 'expired') vẫn được nhận, nhưng 'executed/placed/rejected' không bị ghi đè
      const r = await db.prepare("UPDATE signals SET status=?, ticket=?, note=? WHERE id=? AND status IN ('pending','sent','expired')")
        .bind(b.status, String(b.ticket || ""), String(b.note || ""), String(b.id || "")).run();
      return json({ ok: true, updated: r.meta?.changes ?? 0 });
    }

    // ---- Nhật ký: EA đẩy lệnh đã đóng lên (gửi lại nhiều lần vẫn không bị trùng) ----
    if (path === "/api/ea/deals" && m === "POST") {
      const b = await req.json(); // { account, tzOffset, trades:[{pos,symbol,side,volume,openTime,closeTime,...}] }
      if (!Array.isArray(b.trades)) return json({ error: "thiếu trades" }, 400);
      const off = Number(b.tzOffset) || 0;
      const ms = (t) => (Number(t) - off) * 1000; // giờ server MT5 -> UTC (ms)
      const n = (x) => Number(x) || 0;
      const now = Date.now();
      const stmts = b.trades.filter((t) => t && t.pos).map((t) =>
        db.prepare(`INSERT INTO trades
          (id,account,pos,symbol,side,volume,open_time,close_time,open_price,close_price,sl,tp,profit,commission,swap,fee,magic,comment,reason,updated)
          VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
          ON CONFLICT(id) DO UPDATE SET
            volume=excluded.volume, open_time=excluded.open_time, close_time=excluded.close_time,
            open_price=excluded.open_price, close_price=excluded.close_price, sl=excluded.sl, tp=excluded.tp,
            profit=excluded.profit, commission=excluded.commission, swap=excluded.swap, fee=excluded.fee,
            comment=excluded.comment, reason=excluded.reason, updated=excluded.updated`)
          .bind(`${b.account || 0}-${t.pos}`, String(b.account || ""), String(t.pos), String(t.symbol || ""),
            t.side === "sell" ? "sell" : "buy", n(t.volume), ms(t.openTime), ms(t.closeTime),
            n(t.openPrice), n(t.closePrice), n(t.sl), n(t.tp), n(t.profit), n(t.commission), n(t.swap), n(t.fee),
            n(t.magic), String(t.comment || ""), String(t.reason || ""), now));
      if (stmts.length) await db.batch(stmts);
      return json({ ok: true, saved: stmts.length });
    }

    // Journal đọc: GET /api/trades?since=<ms UTC>&limit=500. since tính theo close_time, bao gồm cả mốc (journal tự dedupe theo id)
    if (path === "/api/trades" && m === "GET") {
      const since = Number(url.searchParams.get("since")) || 0;
      const limit = Math.min(Number(url.searchParams.get("limit")) || 500, 1000);
      const { results } = await db.prepare(
        `SELECT t.*, s.id AS signal_id, s.src AS signal_src, s.otype AS signal_otype, s.rr AS planned_rr
         FROM trades t LEFT JOIN signals s ON s.ticket = t.pos
         WHERE t.close_time >= ? ORDER BY t.close_time ASC LIMIT ?`).bind(since, limit).all();
      for (const t of results) {
        const risk = Math.abs(t.open_price - t.sl);
        t.r = t.sl > 0 && risk > 0 ? ((t.side === "buy" ? 1 : -1) * (t.close_price - t.open_price)) / risk : null; // R thực tế
        t.net = t.profit + t.commission + t.swap + t.fee;
        t.from_bridge = !!t.signal_id;
      }
      return json(results);
    }

    // ---- Đóng vị thế từ web (volume = 0 nghĩa là đóng hết, > 0 là đóng một phần) ----
    if (path === "/api/positions/close" && m === "POST") {
      const b = await req.json();
      const ticket = String(b.ticket || "");
      const volume = Number(b.volume) || 0;
      if (!/^\d+$/.test(ticket) || volume < 0) return json({ error: "dữ liệu không hợp lệ" }, 400);
      const dup = await db.prepare("SELECT id FROM commands WHERE ticket=? AND status='pending'").bind(ticket).first();
      if (dup) return json({ error: "đã có lệnh đóng đang chờ cho vị thế này" }, 409);
      const id = crypto.randomUUID();
      await db.prepare("INSERT INTO commands (id,time,ticket,volume,status,note) VALUES (?,?,?,?,'pending','')")
        .bind(id, Date.now(), ticket, volume).run();
      return json({ ok: true, id });
    }

    if (path === "/api/commands" && m === "GET") {
      const r = await db.prepare("SELECT * FROM commands WHERE id=?").bind(url.searchParams.get("id") || "").first();
      return r ? json(r) : json({ error: "not found" }, 404);
    }

    if (path === "/api/ea/command" && m === "POST") {
      const b = await req.json(); // { id, status: "done"|"rejected", note }
      if (!["done", "rejected"].includes(b.status)) return json({ error: "status sai" }, 400);
      await db.prepare("UPDATE commands SET status=?, note=? WHERE id=?").bind(b.status, String(b.note || ""), b.id).run();
      return json({ ok: true });
    }

    // ---- Sửa SL/TP vị thế từ web (kéo line trên chart, sửa trong bảng). sl/tp = 0 nghĩa là gỡ ----
    // Lệnh sửa cũ của cùng vị thế mà EA chưa nhận sẽ bị thay bằng lệnh mới (web nhận ra qua chữ "thay" trong note).
    if (path === "/api/positions/modify" && m === "POST") {
      const b = await req.json().catch(() => null);
      const ticket = String((b && b.ticket) ?? "");
      const sl = Number(b && b.sl) || 0, tp = Number(b && b.tp) || 0;
      if (!/^\d+$/.test(ticket) || sl < 0 || tp < 0) return json({ error: "dữ liệu không hợp lệ" }, 400);
      await db.prepare("UPDATE modifies SET status='expired', note='Bị lệnh sửa mới hơn thay thế' WHERE ticket=? AND status='pending'").bind(ticket).run();
      const id = crypto.randomUUID();
      await db.prepare("INSERT INTO modifies (id,time,ticket,sl,tp,status,note) VALUES (?,?,?,?,?,'pending','')")
        .bind(id, Date.now(), ticket, sl, tp).run();
      return json({ ok: true, id });
    }

    // Web hỏi kết quả lệnh sửa SL/TP (EA báo lại qua /api/ea/modify)
    if (path === "/api/modifies" && m === "GET") {
      const r = await db.prepare("SELECT * FROM modifies WHERE id=?").bind(url.searchParams.get("id") || "").first();
      return r ? json(r) : json({ error: "not found" }, 404);
    }

    if (path === "/api/ea/modify" && m === "POST") {
      const b = await req.json(); // { id, status: "done"|"rejected", note }
      if (!["done", "rejected"].includes(b.status)) return json({ error: "status sai" }, 400);
      await db.prepare("UPDATE modifies SET status=?, note=? WHERE id=?").bind(b.status, String(b.note || ""), b.id).run();
      return json({ ok: true });
    }

    // ---- Nến M1 cho TPO: EA đẩy nến ĐÃ ĐÓNG, bars = [[t,o,h,l,c,v], ...] (gửi lại không bị trùng) ----
    if (path === "/api/ea/bars" && m === "POST") {
      const b = await req.json();
      const sym = canon(b.symbol);                       // [v1.11] mã broker -> mã chuẩn
      if (!sym || !SYM_RE.test(sym) || !Array.isArray(b.bars) || b.bars.length > 1000) return json({ error: "dữ liệu không hợp lệ" }, 400);
      const bars = b.bars.filter((x) => Array.isArray(x) && x.length >= 6 && x.slice(0, 5).every((v) => Number.isFinite(Number(v))));
      if (bars.length) {
        // 1 câu lệnh duy nhất cho cả lô (json_each) nên không tốn nhiều query của Worker
        await db.prepare(`INSERT INTO bars (symbol,t,o,h,l,c,v)
          SELECT ?1, json_extract(value,'$[0]'), json_extract(value,'$[1]'), json_extract(value,'$[2]'),
                 json_extract(value,'$[3]'), json_extract(value,'$[4]'), json_extract(value,'$[5]')
          FROM json_each(?2) WHERE true
          ON CONFLICT(symbol,t) DO UPDATE SET o=excluded.o, h=excluded.h, l=excluded.l, c=excluded.c, v=excluded.v`)
          .bind(sym, JSON.stringify(bars)).run();
      }
      return json({ ok: true, saved: bars.length });
    }

    // Web đọc: GET /api/bars?symbol=XAUUSD&since=<giờ server, giây>&until=<giây, không bao gồm>. Trả [[t,o,h,l,c,v], ...]
    // Lịch sử lấy từ R2, phần mới lấy từ D1 (trùng phút thì D1 thắng).
    if (path === "/api/bars" && m === "GET") {
      const reqSym = url.searchParams.get("symbol") || "";
      const sym = canon(reqSym);                         // [v1.11] XAUUSD+ / XAUUSDm / XAUUSD đều ra cùng 1 kho
      if (!SYM_RE.test(sym)) return json({ error: "mã không hợp lệ" }, 400);
      const since = Number(url.searchParams.get("since")) || 0;
      const until = Number(url.searchParams.get("until")) || 4102444800;
      const lines = await readRange(env, db, "bars", sym, since, until, CAP.bars);
      return rawJson(`{"symbol":${JSON.stringify(reqSym)},"canon":${JSON.stringify(sym)},"bars":[${lines.join(",")}]}`);
    }

    // ---- Footprint: EA đẩy các phút ĐÃ ĐÓNG, mins = [{t, r:[[giá,mua,bán],...]}, ...] (gửi lại không bị trùng) ----
    if (path === "/api/ea/fp" && m === "POST") {
      const b = await req.json();
      const sym = canon(b.symbol);                       // [v1.11]
      if (!sym || !SYM_RE.test(sym) || !Array.isArray(b.mins) || b.mins.length > 120) return json({ error: "dữ liệu không hợp lệ" }, 400);
      const mins = b.mins.filter((x) => x && Number.isFinite(Number(x.t)) && Array.isArray(x.r)).map((x) => ({ t: Number(x.t), r: x.r }));
      if (mins.length) {
        await db.prepare(`INSERT INTO fp (symbol,t,d)
          SELECT ?1, json_extract(value,'$.t'), json_extract(value,'$.r') FROM json_each(?2) WHERE true
          ON CONFLICT(symbol,t) DO UPDATE SET d=excluded.d`).bind(sym, JSON.stringify(mins)).run();
      }
      return json({ ok: true, saved: mins.length });
    }

    // Web đọc: GET /api/fp?symbol=XAUUSD&since=<giây>&until=<giây>. Trả mins = [[t, [[giá,mua,bán],...]], ...]
    if (path === "/api/fp" && m === "GET") {
      const reqSym = url.searchParams.get("symbol") || "";
      const sym = canon(reqSym);                         // [v1.11]
      if (!SYM_RE.test(sym)) return json({ error: "mã không hợp lệ" }, 400);
      const since = Number(url.searchParams.get("since")) || 0;
      const until = Number(url.searchParams.get("until")) || 4102444800;
      const lines = await readRange(env, db, "fp", sym, since, until, CAP.fp);
      return rawJson(`{"symbol":${JSON.stringify(reqSym)},"canon":${JSON.stringify(sym)},"mins":[${lines.join(",")}]}`);
    }

    // ---- Lịch sử R2 ----
    // Upload 1 ngày: PUT /api/hist/<bars|fp>/<SYMBOL>/<YYYY-MM-DD>[?mode=replace]. Body = các dòng JSON (xem phần R2 ở trên).
    // Mặc định (fill): phút nào đã có trong file R2 thì giữ nguyên, chỉ thêm phút còn thiếu. mode=replace: ghi đè cả file.
    // [v1.11] <SYMBOL> trong URL được đổi sang mã chuẩn: PUT .../XAUUSD+/... cũng ghi vào thư mục XAUUSD.
    const hm = path.match(/^\/api\/hist\/(bars|fp)\/([^/]+)\/(\d{4}-\d{2}-\d{2})$/);
    if (hm && m === "PUT") {
      if (!env.HIST) return json({ error: "chưa gắn R2 bucket tên HIST cho Worker" }, 500);
      const kind = hm[1], day = hm[3];
      let sym = hm[2];
      try { sym = decodeURIComponent(sym); } catch { return json({ error: "mã không hợp lệ" }, 400); }
      sym = canon(sym);
      if (!SYM_RE.test(sym)) return json({ error: "mã không hợp lệ" }, 400);
      const s0 = dayStart(day);
      if (!Number.isFinite(s0)) return json({ error: "ngày không hợp lệ" }, 400);
      const text = await req.text();
      if (text.length > 30e6) return json({ error: "file quá lớn" }, 413);
      let lines = text.replace(/\r/g, "").split("\n").filter((l) => isLine(l) && lineT(l) >= s0 && lineT(l) < s0 + DAY);
      if (!lines.length) return json({ error: "không có dòng hợp lệ trong ngày " + day }, 400);
      try { JSON.parse(lines[0]); JSON.parse(lines[lines.length - 1]); } catch { return json({ error: "dòng không phải JSON hợp lệ" }, 400); }
      const key = `${kind}/${sym}/${day}.txt`;
      const replace = url.searchParams.get("mode") === "replace";
      let kept = 0;
      if (!replace) {
        const old = await env.HIST.get(key);
        if (old) {
          const oldLines = (await old.text()).split("\n").filter(isLine);
          kept = oldLines.length;
          lines = mergeLines(lines, oldLines); // bản cũ thắng
        }
      }
      lines.sort((a, b) => lineT(a) - lineT(b));
      await env.HIST.put(key, lines.join("\n") + "\n", { httpMetadata: { contentType: "text/plain" } });
      idxCache.clear();
      return json({ ok: true, key, lines: lines.length, keptExisting: kept });
    }

    // Xem R2 đã có những ngày nào: GET /api/hist/status?symbol=XAUUSD
    if (path === "/api/hist/status" && m === "GET") {
      const sym = canon(url.searchParams.get("symbol") || "XAUUSD");   // [v1.11]
      if (!SYM_RE.test(sym)) return json({ error: "mã không hợp lệ" }, 400);
      const out = { symbol: sym, r2: !!env.HIST };
      for (const kind of ["bars", "fp"]) {
        const days = await r2Days(env, kind, sym);
        const d1 = await db.prepare(`SELECT MIN(t) a, MAX(t) b, COUNT(*) n FROM ${kind} WHERE symbol=?`).bind(sym).first();
        out[kind] = { r2Days: days.length, r2First: days[0] || null, r2Last: days[days.length - 1] || null,
          d1Rows: d1?.n || 0, d1First: d1?.a ? dayKey(d1.a) : null, d1Last: d1?.b ? dayKey(d1.b) : null };
      }
      return json(out);
    }

    // [v1.11] CHUYỂN dữ liệu cũ từ tên mã cũ sang tên mới (dùng 1 lần để dời XAUUSD+ -> XAUUSD).
    // POST /api/hist/rename?from=XAUUSD%2B&to=XAUUSD&n=10
    //  - R2: mỗi lần chuyển tối đa n file (mặc định 10, tối đa 30): copy sang thư mục mới rồi xóa file cũ.
    //        Nếu file đích đã có thì gộp theo phút, bản ở đích thắng.
    //  - D1: chỉ chuyển khi R2 đã chuyển xong hết. Dòng trùng khóa thì bản ở mã đích thắng, dòng cũ bị xóa.
    //  - Trả về "done": false nghĩa là còn file, gọi lại đúng lệnh đó cho tới khi "done": true.
    if (path === "/api/hist/rename" && m === "POST") {
      if (!env.HIST) return json({ error: "chưa gắn R2 bucket tên HIST cho Worker" }, 500);
      const from = (url.searchParams.get("from") || "").trim();   // KHÔNG canon: đây là tên thư mục thật đang có
      const to = (url.searchParams.get("to") || "").trim();
      if (!SYM_RE.test(from) || !SYM_RE.test(to) || from === to) return json({ error: "from/to không hợp lệ" }, 400);
      let budget = Math.min(Number(url.searchParams.get("n")) || 10, 30);
      let moved = 0;
      for (const kind of ["bars", "fp"]) {
        if (budget <= 0) break;
        const pre = `${kind}/${from}/`, dst = `${kind}/${to}/`;
        const r = await env.HIST.list({ prefix: pre, limit: budget });
        for (const o of r.objects) {
          const src = await env.HIST.get(o.key);
          if (!src) continue;
          const nk = dst + o.key.slice(pre.length);
          let txt = await src.text();
          const ex = await env.HIST.get(nk);
          if (ex) txt = mergeLines(txt.split("\n").filter(isLine), (await ex.text()).split("\n").filter(isLine)).join("\n") + "\n";
          await env.HIST.put(nk, txt, { httpMetadata: { contentType: "text/plain" } });
          await env.HIST.delete(o.key);
          moved++; budget--;
        }
      }
      let left = 0;
      for (const kind of ["bars", "fp"]) left += (await env.HIST.list({ prefix: `${kind}/${from}/`, limit: 1 })).objects.length;
      let d1 = null;
      if (left === 0) {
        d1 = {};
        for (const tb of ["bars", "fp"]) {
          const a = await db.prepare(`UPDATE OR IGNORE ${tb} SET symbol=? WHERE symbol=?`).bind(to, from).run();
          const b2 = await db.prepare(`DELETE FROM ${tb} WHERE symbol=?`).bind(from).run();
          d1[tb] = { moved: a.meta?.changes ?? 0, droppedDuplicates: b2.meta?.changes ?? 0 };
        }
      }
      idxCache.clear();
      return json({ ok: true, from, to, r2Moved: moved, done: left === 0, d1 });
    }

    // Chạy tay việc chuyển dữ liệu D1 cũ sang R2 (cron cũng gọi đúng hàm này): POST /api/hist/compact?days=5
    if (path === "/api/hist/compact" && m === "POST") {
      return json(await compact(env, Math.min(Number(url.searchParams.get("days")) || 2, 20)));
    }

    return json({ error: "not found" }, 404);
}

export default {
  async fetch(req, env) {
    try {
      return await handle(req, env);
    } catch (e) {
      console.log("lỗi xử lý", req.method, new URL(req.url).pathname, e && e.message);
      if (e instanceof SyntaxError) return json({ error: "JSON không hợp lệ" }, 400);
      return json({ error: "lỗi máy chủ" }, 500);   // luôn có CORS để web đọc được lỗi, không bị báo nhầm là sai URL
    }
  },

  // Cron Trigger (đặt trong Settings > Triggers, ví dụ mỗi giờ): chuyển nến/footprint cũ từ D1 sang R2
  async scheduled(event, env, ctx) {
    ctx.waitUntil(compact(env, 2).catch((e) => console.log("compact lỗi", e && e.message)));
  },
};
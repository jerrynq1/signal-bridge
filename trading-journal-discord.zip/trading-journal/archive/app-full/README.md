# Trade Platform

Web giao dịch chạy thuần trên trình duyệt, đăng bằng GitHub Pages. Không cần cài đặt hay build.

## Cấu trúc thư mục

```
index.html                       Khung trang + danh sách file nạp (thứ tự nạp RẤT quan trọng)
css/style.css                    Toàn bộ giao diện
js/
  core.js                        Hàm tiện ích dùng chung ($, ld, sv, danh sách khung giờ)
  ea-setting.js                  Tab "EA Setting"
  timezone.js                    Múi giờ, giờ server MT5
  chart.js                       Chart nến, tải M1, gộp khung giờ, cập nhật live
  candle-style.js                Màu nến
  indicators-defs.js             KHO INDICATOR: định nghĩa từng indicator (tên, thông số, công thức)
                                 -> thêm/sửa thông số của Statistic, Footprint, Big Trade, EMA, RSI... ở đây
  indicators-engine.js           Dựng pane, hộp cài đặt, danh sách indicator đang bật
  connection-ui.js               Kết nối API, sidebar, theme, nền sao
  journal-flexcard-sync.js       Journal, Analytic, Flex Card, đồng bộ MT5 (cùng một khối, không tách được)
  manual-order.js                Nút BUY / SELL gửi về EA
  init.js                        Khởi động app (chạy trước các file bên dưới)
  drawings-core.js               Thanh công cụ vẽ, toạ độ, hình vẽ
  volume-profile.js              Volume Profile
  orderflow-footprint.js         Indicator Footprint
  orderflow-bigtrade.js          Indicator Big Trade
  orderflow-statistic.js         Indicator Statistic (bảng số liệu dưới chart, độc lập với Footprint)
  drawings-interact.js           Vẽ lại chart, chạm/chọn hình, sự kiện chuột
  mobile.js                      Điều chỉnh cho điện thoại
  i18n-data.js                   BẢNG DỊCH Việt / English / 中文 (thêm chữ mới vào đây)
  i18n.js                        Bộ dịch giao diện
```

## Đưa lên GitHub Pages

1. Giải nén file zip. Bạn sẽ có `index.html`, thư mục `css` và thư mục `js`.
2. Vào repo GitHub của bạn.
   - Nếu file cũ tên **khác** `index.html` (ví dụ `trading-platform.html`), mở file đó, bấm biểu tượng thùng rác, rồi **Commit**. Nếu không, file cũ vẫn còn truy cập được.
   - Nếu file cũ đã tên `index.html` thì không cần xóa, upload đè lên là được.
3. Bấm **Add file → Upload files**. Kéo **toàn bộ nội dung** vừa giải nén (`index.html`, `css`, `js`) vào khung. Chrome và Edge nhận cả thư mục. Phải thấy đường dẫn dạng `js/core.js` trong danh sách.
4. Cuộn xuống, bấm **Commit changes**.
5. Vào **Settings → Pages**. Mục **Source** chọn *Deploy from a branch*, **Branch** chọn `main`, thư mục `/ (root)`, bấm **Save**. Nếu trước giờ trang đã chạy được thì bước này đã đúng sẵn.
6. Đợi 1 đến 2 phút rồi mở `https://TÊN-GITHUB.github.io/TÊN-REPO/`. Bấm **Ctrl + F5** để bỏ bộ nhớ đệm.

Nếu GitHub không nhận thư mục khi kéo thả, dùng **GitHub Desktop**: Clone repo về máy, chép các file vào thư mục repo, bấm **Commit to main** rồi **Push origin**.

## Khi sửa file về sau

- Chỉ upload **file bạn đã sửa** (giữ đúng thư mục, ví dụ `js/orderflow-statistic.js`). Không cần upload lại cả bộ.
- Trình duyệt hay giữ file JS cũ trong bộ nhớ đệm. Sau mỗi lần đăng bản mới, mở `index.html`, dùng **Tìm và Thay thế tất cả** đổi `?v=1` thành `?v=2` (lần sau `?v=3`...) rồi upload lại `index.html`. Khi đó người dùng sẽ tải bản mới ngay.
- **Không đổi thứ tự** các dòng `<script>` trong `index.html`. Các file dùng chung biến toàn cục nên phải nạp đúng thứ tự.
- Khi viết code mới, tránh đặt tên biến trùng tên đã có ở file khác (ví dụ `cur`, `IC`, `n`). Hai file khai báo cùng một tên `const` sẽ làm file sau không chạy và báo lỗi trong Console (F12).
- Nên giữ lại bản 1 file cũ trên máy làm bản sao lưu.

## Khi trang không lên hoặc bị trắng

Bấm **F12 → Console**. Lỗi dạng `Failed to load resource ... js/xxx.js` nghĩa là thiếu file hoặc sai thư mục khi upload. Lỗi `SyntaxError` hoặc `already been declared` chỉ ra đúng file và dòng bị lỗi.

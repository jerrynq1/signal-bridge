//+------------------------------------------------------------------+
//| SignalBridge.mq5                                                 |
//| Hỏi Cloudflare API mỗi vài giây, nhận tín hiệu "chờ" và vào lệnh |
//| theo Cài đặt EA trên web. Dành cho tài khoản HEDGING.            |
//| v1.10: thêm sửa SL/TP vị thế từ web (kéo line trên chart)        |
//| v1.11: tự quy đổi mã khi đổi broker (XAUUSD+ <-> XAUUSD <-> ...) |
//+------------------------------------------------------------------+
#property copyright "Signal Bridge"
#property version   "1.11"
#include <Trade\Trade.mqh>

input string InpApiUrl  = "https://signal-bridge.TEN-ACCOUNT.workers.dev"; // API base URL (không có / ở cuối)
input string InpToken   = "";                                              // Secret token (TOKEN trên Cloudflare)
input int    InpPollSec = 1;                                               // Hỏi API và gửi giá mỗi N giây
input int    InpSyncSec = 30;                                              // Đồng bộ lệnh đã đóng lên API mỗi N giây (cho nhật ký)
input int    InpBackfillDays = 30;                                         // Lần chạy đầu: lấy lại lịch sử bao nhiêu ngày
input string InpBarSymbol = "XAUUSD";                                      // Danh sách mã MT5 cho chart/TPO/footprint, cách nhau bằng dấu phẩy, đúng tên trên broker (vd XAUUSD+,NAS100,EURUSD)
input int    InpBarDays   = 14;                                       // Lần chạy đầu: gửi bù bao nhiêu ngày nến M1
input bool   InpFpOn      = true;                                          // Footprint: gửi dữ liệu mua/bán theo mức giá (từ tick)
input int    InpFpDays    = 14;                                            // Footprint: gửi bù bao nhiêu ngày tick (tối đa bằng InpBarDays; tick cũ phụ thuộc broker)

CTrade trade;

struct Cfg
{
   bool   enabled, allowLong, allowShort, useSession;
   string symbolMap, lotMode, priceMode, tpMode, sessFrom, sessTo;
   double lot, riskPct, maxSpread, offset, rr, beAtR;
   int    maxTradesDay, maxOpen, slippage, pendingMin;
   long   magic;
};
Cfg g_cfg;

struct FpState { double bid; double ask; int side; };

// Trạng thái đồng bộ nến M1 + footprint RIÊNG cho từng mã trong InpBarSymbol
struct SymSt
{
   string   sym;
   datetime barSentT;   // open time nến đóng gần nhất đã gửi xong
   datetime barSeenT;   // open time nến đang chạy ở lần gửi thành công gần nhất
   datetime barRetry;
   bool     barInit;
   int      barWait;    // số lần đã chờ MT5 tải lịch sử M1 của mã này
   FpState  fps;        // trạng thái tick-rule tại cuối phút đã xử lý
   datetime fpSentT;    // con trỏ TIẾN: open time phút đã đóng gần nhất đã gửi xong
   datetime fpBackT;    // con trỏ LÙI: đang gửi bù dần về quá khứ
   datetime fpRetry;
   datetime fpSkipT;    // phút đang bị lỗi
   bool     fpInit;
   int      fpFail;     // số lần liên tiếp không đọc được tick của 1 phút
};
SymSt g_ss[];
int   g_nss = 0;

string BuildLiveFp(SymSt &s);

string g_done[];          // id đã xử lý, tránh vào lệnh 2 lần nếu báo cáo thất bại
int    g_doneN = 0;
string g_apiUrl;
datetime g_lastErrLog = 0;
string g_status = "Đang khởi động...";
bool   g_lastPlaced = false;   // true nếu tín hiệu vừa xử lý là lệnh chờ (limit/stop)
int    g_tickCnt = 1000;       // đếm số nhịp timer 1 giây từ lần hỏi API gần nhất
ulong  g_sentPid[];            // position đã gửi lên API (khỏi gửi lại mỗi 30 giây)
int    g_sentN = 0;

//------------------------------------------------------------------
// JSON tối giản
//------------------------------------------------------------------
string JsonRaw(const string json, const string key)
{
   string pat = "\"" + key + "\":";
   int p = StringFind(json, pat);
   if(p < 0) return "";
   p += StringLen(pat);
   int n = StringLen(json);
   while(p < n && StringGetCharacter(json, p) == ' ') p++;
   if(p >= n) return "";
   if(StringGetCharacter(json, p) == '"')
   {
      string out = "";
      p++;
      while(p < n)
      {
         ushort c = StringGetCharacter(json, p);
         if(c == '\\' && p + 1 < n)
         {
            ushort d = StringGetCharacter(json, p + 1);
            if(d == 'n')       out += "\n";
            else if(d == 'r')  { }
            else               out += ShortToString(d);
            p += 2;
            continue;
         }
         if(c == '"') break;
         out += ShortToString(c);
         p++;
      }
      return out;
   }
   int q = p;
   while(q < n)
   {
      ushort c = StringGetCharacter(json, q);
      if(c == ',' || c == '}' || c == ']') break;
      q++;
   }
   return StringSubstr(json, p, q - p);
}

double GetD(const string j, const string k, double def) { string r = JsonRaw(j, k); return r == "" || r == "null" ? def : StringToDouble(r); }
long   GetL(const string j, const string k, long def)   { string r = JsonRaw(j, k); return r == "" || r == "null" ? def : StringToInteger(r); }
bool   GetB(const string j, const string k, bool def)   { string r = JsonRaw(j, k); return r == "" ? def : (r == "true"); }
string GetS(const string j, const string k, string def) { string r = JsonRaw(j, k); return r == "" ? def : r; }

string JsonEsc(string s)
{
   StringReplace(s, "\\", "\\\\");
   StringReplace(s, "\"", "'");
   StringReplace(s, "\n", " ");
   return s;
}

void ParseCfg(const string j)
{
   g_cfg.enabled      = GetB(j, "enabled", false);
   g_cfg.allowLong    = GetB(j, "allowLong", true);
   g_cfg.allowShort   = GetB(j, "allowShort", true);
   g_cfg.useSession   = GetB(j, "useSession", false);
   g_cfg.symbolMap    = GetS(j, "symbolMap", "");
   g_cfg.lotMode      = GetS(j, "lotMode", "fixed");
   g_cfg.priceMode    = GetS(j, "priceMode", "distance");
   g_cfg.tpMode       = GetS(j, "tpMode", "strategy");
   g_cfg.sessFrom     = GetS(j, "sessFrom", "00:00");
   g_cfg.sessTo       = GetS(j, "sessTo", "23:59");
   g_cfg.lot          = GetD(j, "lot", 0.01);
   g_cfg.riskPct      = GetD(j, "riskPct", 1.0);
   g_cfg.maxSpread    = GetD(j, "maxSpread", 40);
   g_cfg.offset       = GetD(j, "offset", 0);
   g_cfg.rr           = GetD(j, "rr", 2.0);
   g_cfg.beAtR        = GetD(j, "beAtR", 0);
   g_cfg.maxTradesDay = (int)GetL(j, "maxTradesDay", 3);
   g_cfg.maxOpen      = (int)GetL(j, "maxOpen", 1);
   g_cfg.slippage     = (int)GetL(j, "slippage", 30);
   g_cfg.pendingMin   = (int)GetL(j, "pendingMin", 0);
   g_cfg.magic        = GetL(j, "magic", 20261016);
}

//------------------------------------------------------------------
// HTTP
//------------------------------------------------------------------
int Http(const string method, const string path, const string body, string &resp)
{
   char data[], result[];
   string rh;
   string headers = "Content-Type: application/json\r\nX-Token: " + InpToken + "\r\n";
   if(body != "")
   {
      int n = StringToCharArray(body, data, 0, WHOLE_ARRAY, CP_UTF8);
      ArrayResize(data, n - 1);
   }
   ResetLastError();
   int code = WebRequest(method, g_apiUrl + path, headers, 5000, data, result, rh);
   resp = (code == -1) ? "" : CharArrayToString(result, 0, WHOLE_ARRAY, CP_UTF8);
   if(code == -1 && TimeCurrent() - g_lastErrLog > 30)
   {
      g_lastErrLog = TimeCurrent();
      int e = GetLastError();
      PrintFormat("SignalBridge: WebRequest lỗi %d. %s", e,
                  e == 4014 ? "Chưa thêm URL vào Tools > Options > Expert Advisors > Allow WebRequest." : "Kiểm tra mạng và API URL.");
   }
   return code;
}

void Report(const string id, const string status, ulong ticket, const string note)
{
   string body = "{\"id\":\"" + id + "\",\"status\":\"" + status + "\",\"ticket\":\"" + (string)ticket +
                 "\",\"note\":\"" + JsonEsc(note) + "\"}";
   string resp;
   Http("POST", "/api/ea/report", body, resp);
}

//------------------------------------------------------------------
// Tiện ích giao dịch
//------------------------------------------------------------------
string Trim(string s) { StringTrimLeft(s); StringTrimRight(s); return s; }

string MapSymbol(const string ticker)
{
   string lines[];
   int n = StringSplit(g_cfg.symbolMap, '\n', lines);
   string t = ticker;
   StringToUpper(t);
   for(int i = 0; i < n; i++)
   {
      string kv[];
      if(StringSplit(lines[i], '=', kv) < 2) continue;
      string a = Trim(kv[0]);
      StringToUpper(a);
      if(a == t) return Trim(kv[1]);
   }
   return "";
}

int HHMM(const string s)
{
   string p[];
   if(StringSplit(s, ':', p) < 2) return 0;
   return (int)StringToInteger(p[0]) * 60 + (int)StringToInteger(p[1]);
}

bool InSession()
{
   if(!g_cfg.useSession) return true;
   int a = HHMM(g_cfg.sessFrom), b = HHMM(g_cfg.sessTo);
   MqlDateTime t;
   TimeToStruct(TimeCurrent(), t);
   int now = t.hour * 60 + t.min;
   if(a <= b) return now >= a && now < b;
   return now >= a || now < b;
}

int CountOpen()
{
   int c = 0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong tk = PositionGetTicket(i);
      if(tk > 0 && PositionGetInteger(POSITION_MAGIC) == g_cfg.magic) c++;
   }
   return c;
}

int CountPending()
{
   int c = 0;
   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      ulong tk = OrderGetTicket(i);
      if(tk > 0 && OrderGetInteger(ORDER_MAGIC) == g_cfg.magic) c++;
   }
   return c;
}

int CountTradesToday()
{
   MqlDateTime t;
   TimeToStruct(TimeCurrent(), t);
   t.hour = 0; t.min = 0; t.sec = 0;
   datetime day0 = StructToTime(t);
   if(!HistorySelect(day0, TimeCurrent() + 60)) return 0;
   int c = 0;
   for(int i = HistoryDealsTotal() - 1; i >= 0; i--)
   {
      ulong d = HistoryDealGetTicket(i);
      if(d == 0) continue;
      if(HistoryDealGetInteger(d, DEAL_MAGIC) == g_cfg.magic && HistoryDealGetInteger(d, DEAL_ENTRY) == DEAL_ENTRY_IN) c++;
   }
   return c;
}

double NormLot(const string sym, double lot)
{
   double step = SymbolInfoDouble(sym, SYMBOL_VOLUME_STEP);
   double vmin = SymbolInfoDouble(sym, SYMBOL_VOLUME_MIN);
   double vmax = SymbolInfoDouble(sym, SYMBOL_VOLUME_MAX);
   if(step <= 0) return 0;
   lot = MathFloor(lot / step + 1e-9) * step;
   if(lot < vmin) return 0;
   lot = MathMin(lot, vmax);
   int dg = (int)MathMax(0, MathRound(-MathLog10(step)));
   return NormalizeDouble(lot, dg);
}

double CalcLot(const string sym, bool isBuy, double price, double sl)
{
   if(g_cfg.lotMode != "risk") return NormLot(sym, g_cfg.lot);
   double risk = AccountInfoDouble(ACCOUNT_BALANCE) * g_cfg.riskPct / 100.0;
   double loss = 0;
   if(!OrderCalcProfit(isBuy ? ORDER_TYPE_BUY : ORDER_TYPE_SELL, sym, 1.0, price, sl, loss) || loss >= 0) return 0;
   return NormLot(sym, risk / MathAbs(loss));
}

//------------------------------------------------------------------
// [v1.11] Mã chuẩn + tự tìm mã đúng ở broker hiện tại (giống canon() trên Worker)
// Web có thể gửi lệnh với mã của sàn cũ (vd XAUUSD+), sàn mới gọi là XAUUSD / XAUUSDm / GOLD...
//------------------------------------------------------------------
string CanonSym(string s)
{
   StringToUpper(s);
   StringTrimLeft(s); StringTrimRight(s);
   if(s == "GOLD" || s == "GOLDM" || s == "XAU/USD") return "XAUUSD";
   int n = StringLen(s);
   for(int i = 0; i < n; i++)
   {
      ushort c = StringGetCharacter(s, i);
      if(c == '.' || c == '#' || c == '+' || c == '_' || c == '-') { s = StringSubstr(s, 0, i); break; }
   }
   if(s == "GOLD" || s == "GOLDM") return "XAUUSD";
   if(StringLen(s) > 6)
   {
      string base = StringSubstr(s, 0, 6), suf = StringSubstr(s, 6);
      bool letters = true;
      for(int i = 0; i < 6; i++)
      {
         ushort c = StringGetCharacter(base, i);
         if(c < 'A' || c > 'Z') { letters = false; break; }
      }
      if(letters && (suf == "M" || suf == "C" || suf == "I" || suf == "Z" || suf == "PRO" || suf == "RAW" || suf == "ECN" || suf == "STD"))
         return base;
   }
   return s;
}

// Trả về tên mã có thật ở broker ứng với "want", hoặc "" nếu không có.
string ResolveSymbol(const string want)
{
   if(want == "") return "";
   if(SymbolSelect(want, true)) return want;                      // đúng tên sẵn rồi
   string cw = CanonSym(want);

   // 1) Các mã trong InpBarSymbol (bạn đã ghi đúng tên broker)
   for(int k = 0; k < g_nss; k++)
      if(CanonSym(g_ss[k].sym) == cw && SymbolSelect(g_ss[k].sym, true)) return g_ss[k].sym;

   // 2) Vế phải trong ánh xạ mã (Cài đặt EA)
   string lines[];
   int n = StringSplit(g_cfg.symbolMap, '\n', lines);
   for(int i = 0; i < n; i++)
   {
      string kv[];
      if(StringSplit(lines[i], '=', kv) < 2) continue;
      string r = Trim(kv[1]);
      if(r != "" && (CanonSym(r) == cw || CanonSym(kv[0]) == cw) && SymbolSelect(r, true)) return r;
   }

   // 3) Quét toàn bộ mã của broker, lấy mã trùng mã chuẩn (ưu tiên tên giống hệt mã chuẩn, rồi tên ngắn nhất, và mã đang cho phép giao dịch)
   string best = "";
   int bestScore = -1;
   int total = SymbolsTotal(false);
   for(int i = 0; i < total; i++)
   {
      string nm = SymbolName(i, false);
      if(CanonSym(nm) != cw) continue;
      int score = 1000 - StringLen(nm);
      string up = nm; StringToUpper(up);
      if(up == cw) score += 500;
      if(SymbolInfoInteger(SymbolName(i, false), SYMBOL_TRADE_MODE) == SYMBOL_TRADE_MODE_DISABLED) score -= 2000;
      if(score > bestScore) { bestScore = score; best = SymbolName(i, false); }
   }
   if(best != "" && SymbolSelect(best, true)) return best;
   return "";
}

//------------------------------------------------------------------
// Xử lý 1 tín hiệu
//------------------------------------------------------------------
bool Execute(const string obj, ulong &ticket, string &note)
{
   ticket = 0;
   string action = JsonRaw(obj, "action");
   string ticker = JsonRaw(obj, "ticker");
   string id     = JsonRaw(obj, "id");
   double sEntry = StringToDouble(JsonRaw(obj, "entry"));
   double sSl    = StringToDouble(JsonRaw(obj, "sl"));
   double sTp    = StringToDouble(JsonRaw(obj, "tp"));
   double sLot   = StringToDouble(JsonRaw(obj, "lot"));     // lệnh tay: lot gửi từ web
   bool   isManual = (JsonRaw(obj, "src") == "manual");
   bool isBuy = (action == "buy");
   string otype = JsonRaw(obj, "otype");
   if(otype == "") otype = "market";
   bool isMarket = (otype == "market");
   bool useAbs   = (JsonRaw(obj, "src") == "manual") || !isMarket; // lệnh nhập tay: giá là giá MT5, không quy đổi
   g_lastPlaced = false;

   if(action != "buy" && action != "sell") { note = "Hướng lệnh không hợp lệ"; return false; }
   if(!g_cfg.enabled)                      { note = "Công tắc 'Cho phép EA vào lệnh' đang tắt"; return false; }
   if(isBuy && !g_cfg.allowLong)           { note = "LONG đang bị tắt"; return false; }
   if(!isBuy && !g_cfg.allowShort)         { note = "SHORT đang bị tắt"; return false; }
   if(!TerminalInfoInteger(TERMINAL_TRADE_ALLOWED) || !MQLInfoInteger(MQL_TRADE_ALLOWED))
                                           { note = "Algo Trading đang tắt trong MT5"; return false; }
   if(!InSession())                        { note = "Ngoài khung giờ giao dịch"; return false; }

   string sym = MapSymbol(ticker);
   if(sym == "" && isManual) sym = ticker;   // lệnh tay: dùng thẳng mã MT5 đang xem trên chart
   if(sym == "")                           { note = "Chưa ánh xạ mã " + ticker + " (Cài đặt EA)"; return false; }
   string want = sym;
   sym = ResolveSymbol(want);                // [v1.11] tự đổi sang mã đúng của broker hiện tại
   if(sym == "")                           { note = "Không tìm thấy mã " + want + " ở broker"; return false; }

   if(g_cfg.maxOpen > 0 && CountOpen() + CountPending() >= g_cfg.maxOpen)
                                           { note = "Đã đủ số lệnh đang mở tối đa"; return false; }
   if(g_cfg.maxTradesDay > 0 && CountTradesToday() >= g_cfg.maxTradesDay)
                                           { note = "Đã đủ số lệnh tối đa trong ngày"; return false; }

   double point  = SymbolInfoDouble(sym, SYMBOL_POINT);
   int    digits = (int)SymbolInfoInteger(sym, SYMBOL_DIGITS);
   long   spread = SymbolInfoInteger(sym, SYMBOL_SPREAD);
   if(isMarket && g_cfg.maxSpread > 0 && spread > g_cfg.maxSpread)
                                           { note = "Spread " + (string)spread + " lớn hơn mức cho phép"; return false; }

   double price = isBuy ? SymbolInfoDouble(sym, SYMBOL_ASK) : SymbolInfoDouble(sym, SYMBOL_BID);
   if(price <= 0)                          { note = "Không lấy được giá " + sym; return false; }

   double sl, tp, entry = price;
   if(!isMarket) entry = NormalizeDouble(sEntry, digits);
   if(useAbs)
   {
      sl = sSl;
      tp = sTp;
   }
   else if(g_cfg.priceMode == "absolute")
   {
      sl = sSl + g_cfg.offset;
      tp = (g_cfg.tpMode == "rr") ? (isBuy ? price + g_cfg.rr * MathAbs(price - sl) : price - g_cfg.rr * MathAbs(price - sl))
                                  : sTp + g_cfg.offset;
   }
   else
   {
      double slDist = MathAbs(sEntry - sSl);
      double tpDist = (g_cfg.tpMode == "rr") ? g_cfg.rr * slDist : MathAbs(sTp - sEntry);
      sl = isBuy ? price - slDist : price + slDist;
      tp = isBuy ? price + tpDist : price - tpDist;
   }
   sl = NormalizeDouble(sl, digits);
   tp = NormalizeDouble(tp, digits);

   double minDist = SymbolInfoInteger(sym, SYMBOL_TRADE_STOPS_LEVEL) * point;
   if(isManual)
   {
      // Lệnh tay: SL/TP không bắt buộc (0 = không đặt). Nếu có thì phải đúng phía và đủ xa giá.
      if(sl < 0 || tp < 0)                  { note = "SL/TP không hợp lệ"; return false; }
      if(sl > 0 && (isBuy ? !(sl < entry) : !(sl > entry))) { note = "SL nằm sai phía so với giá hiện tại"; return false; }
      if(tp > 0 && (isBuy ? !(tp > entry) : !(tp < entry))) { note = "TP nằm sai phía so với giá hiện tại"; return false; }
      if((sl > 0 && MathAbs(entry - sl) < minDist) || (tp > 0 && MathAbs(tp - entry) < minDist))
                                           { note = "SL/TP quá gần giá (stops level của broker)"; return false; }
   }
   else
   {
   if(isBuy ? !(sl < entry && tp > entry) : !(sl > entry && tp < entry))
                                           { note = "SL/TP nằm sai phía so với giá hiện tại"; return false; }
   if(MathAbs(entry - sl) < minDist || MathAbs(tp - entry) < minDist)
                                           { note = "SL/TP quá gần giá (stops level của broker)"; return false; }
   }

   ENUM_ORDER_TYPE ot = isBuy ? ORDER_TYPE_BUY : ORDER_TYPE_SELL;
   if(!isMarket)
   {
      if(otype == "limit")
      {
         if(isBuy ? !(entry < price) : !(entry > price))
                                           { note = isBuy ? "Buy Limit phải đặt dưới giá Ask hiện tại" : "Sell Limit phải đặt trên giá Bid hiện tại"; return false; }
         ot = isBuy ? ORDER_TYPE_BUY_LIMIT : ORDER_TYPE_SELL_LIMIT;
      }
      else if(otype == "stop")
      {
         if(isBuy ? !(entry > price) : !(entry < price))
                                           { note = isBuy ? "Buy Stop phải đặt trên giá Ask hiện tại" : "Sell Stop phải đặt dưới giá Bid hiện tại"; return false; }
         ot = isBuy ? ORDER_TYPE_BUY_STOP : ORDER_TYPE_SELL_STOP;
      }
      else                                 { note = "Loại lệnh không hợp lệ: " + otype; return false; }
      if(MathAbs(entry - price) < minDist)
                                           { note = "Giá vào quá gần giá hiện tại (stops level của broker)"; return false; }
   }

   double lot = (isManual && sLot > 0) ? NormLot(sym, sLot) : CalcLot(sym, isBuy, entry, sl);
   if(lot <= 0)                            { note = "Lot tính ra nhỏ hơn lot tối thiểu của broker"; return false; }

   trade.SetExpertMagicNumber((ulong)g_cfg.magic);
   trade.SetDeviationInPoints(g_cfg.slippage);
   trade.SetTypeFillingBySymbol(sym);
   string cmt = "SB " + StringSubstr(id, 0, 8);
   bool ok;
   if(isMarket)
      ok = isBuy ? trade.Buy(lot, sym, 0, sl, tp, cmt) : trade.Sell(lot, sym, 0, sl, tp, cmt);
   else
   {
      datetime exp = (g_cfg.pendingMin > 0) ? TimeCurrent() + (datetime)g_cfg.pendingMin * 60 : 0;
      ok = trade.OrderOpen(sym, ot, lot, 0, entry, sl, tp, exp > 0 ? ORDER_TIME_SPECIFIED : ORDER_TIME_GTC, exp, cmt);
   }
   uint rc = trade.ResultRetcode();
   if(!ok || (rc != TRADE_RETCODE_DONE && rc != TRADE_RETCODE_PLACED && rc != TRADE_RETCODE_DONE_PARTIAL))
   {
      note = "Broker từ chối: " + trade.ResultRetcodeDescription();
      return false;
   }
   ticket = trade.ResultOrder();
   if(sl > 0) GlobalVariableSet("SB_R_" + (string)ticket, MathAbs(entry - sl)); // lưu R để dời SL hòa vốn (lệnh chờ khớp dùng cùng ticket trên tài khoản hedging)
   g_lastPlaced = !isMarket;
   string tn = isBuy ? "BUY" : "SELL";
   if(!isMarket) tn += (otype == "limit") ? " LIMIT" : " STOP";
   note = StringFormat("%s %s %.2f lot @ %s", tn, sym, lot, DoubleToString(isMarket ? price : entry, digits));
   return true;
}

bool IsDone(const string id)
{
   for(int i = 0; i < g_doneN; i++) if(g_done[i] == id) return true;
   return false;
}

void MarkDone(const string id)
{
   if(g_doneN >= 300)
   {
      for(int i = 1; i < g_doneN; i++) g_done[i - 1] = g_done[i];
      g_doneN--;
   }
   ArrayResize(g_done, g_doneN + 1);
   g_done[g_doneN++] = id;
}

void HandleSignal(const string obj)
{
   string id = JsonRaw(obj, "id");
   if(id == "" || IsDone(id)) return;
   MarkDone(id);
   ulong ticket;
   string note;
   bool ok = Execute(obj, ticket, note);
   PrintFormat("SignalBridge: %s -> %s | %s", id, ok ? "executed" : "rejected", note);
   Report(id, ok ? (g_lastPlaced ? "placed" : "executed") : "rejected", ticket, note);
}

//------------------------------------------------------------------
// Dời SL về hòa vốn khi lời đạt x R
//------------------------------------------------------------------
void ManageBreakEven()
{
   if(g_cfg.beAtR <= 0) return;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong tk = PositionGetTicket(i);
      if(tk == 0 || PositionGetInteger(POSITION_MAGIC) != g_cfg.magic) continue;
      string gv = "SB_R_" + (string)tk;
      if(!GlobalVariableCheck(gv)) continue;
      double R = GlobalVariableGet(gv);
      string sym = PositionGetString(POSITION_SYMBOL);
      double open = PositionGetDouble(POSITION_PRICE_OPEN);
      double sl = PositionGetDouble(POSITION_SL);
      double tp = PositionGetDouble(POSITION_TP);
      double point = SymbolInfoDouble(sym, SYMBOL_POINT);
      double minDist = SymbolInfoInteger(sym, SYMBOL_TRADE_STOPS_LEVEL) * point;
      bool buy = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY);
      double cur = buy ? SymbolInfoDouble(sym, SYMBOL_BID) : SymbolInfoDouble(sym, SYMBOL_ASK);
      double moved = buy ? cur - open : open - cur;
      bool already = buy ? (sl >= open - point / 2) : (sl > 0 && sl <= open + point / 2);
      if(!already && moved >= g_cfg.beAtR * R && moved >= minDist)
      {
         trade.SetExpertMagicNumber((ulong)g_cfg.magic);
         if(trade.PositionModify(tk, open, tp)) PrintFormat("SignalBridge: dời SL về hòa vốn #%I64u", tk);
      }
   }
}

//------------------------------------------------------------------
// Danh sách vị thế đang mở (gửi kèm quote để web hiển thị)
//------------------------------------------------------------------
string BuildPositions()
{
   string items = "";
   int total = MathMin(PositionsTotal(), 40);
   for(int i = 0; i < total; i++)
   {
      ulong tk = PositionGetTicket(i);
      if(tk == 0) continue;
      string sym = PositionGetString(POSITION_SYMBOL);
      int dg = (int)SymbolInfoInteger(sym, SYMBOL_DIGITS);
      if(items != "") items += ",";
      items += "{\"ticket\":\"" + (string)tk + "\",\"symbol\":\"" + JsonEsc(sym) + "\",\"side\":\"" +
               (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY ? "buy" : "sell") +
               "\",\"volume\":" + DoubleToString(PositionGetDouble(POSITION_VOLUME), 4) +
               ",\"open\":" + DoubleToString(PositionGetDouble(POSITION_PRICE_OPEN), dg) +
               ",\"price\":" + DoubleToString(PositionGetDouble(POSITION_PRICE_CURRENT), dg) +
               ",\"sl\":" + DoubleToString(PositionGetDouble(POSITION_SL), dg) +
               ",\"tp\":" + DoubleToString(PositionGetDouble(POSITION_TP), dg) +
               ",\"profit\":" + DoubleToString(PositionGetDouble(POSITION_PROFIT), 2) +
               ",\"swap\":" + DoubleToString(PositionGetDouble(POSITION_SWAP), 2) +
               ",\"time\":" + (string)(long)PositionGetInteger(POSITION_TIME) +
               ",\"magic\":" + (string)PositionGetInteger(POSITION_MAGIC) + ",\"dg\":" + (string)dg + "}";
   }
   return items;
}

//------------------------------------------------------------------
// Đóng vị thế theo lệnh từ web (đóng hết hoặc đóng một phần)
// Không bị chặn bởi công tắc "Cho phép EA vào lệnh": đóng lệnh là giảm rủi ro.
//------------------------------------------------------------------
bool ClosePos(const string ticketStr, const double reqVol, string &note)
{
   ulong tk = (ulong)StringToInteger(ticketStr);
   if(tk == 0 || !PositionSelectByTicket(tk))
                                           { note = "Không tìm thấy lệnh #" + ticketStr + " (có thể đã đóng)"; return false; }
   if(!TerminalInfoInteger(TERMINAL_TRADE_ALLOWED) || !MQLInfoInteger(MQL_TRADE_ALLOWED))
                                           { note = "Algo Trading đang tắt trong MT5"; return false; }
   string sym = PositionGetString(POSITION_SYMBOL);
   double vol = PositionGetDouble(POSITION_VOLUME);
   double vmin = SymbolInfoDouble(sym, SYMBOL_VOLUME_MIN);
   trade.SetDeviationInPoints(g_cfg.slippage);
   trade.SetTypeFillingBySymbol(sym);
   bool ok;
   double closed = vol;
   if(reqVol > 0 && reqVol < vol - 1e-9)
   {
      closed = NormLot(sym, reqVol);       // làm tròn xuống theo bước lot của broker
      if(closed <= 0)                      { note = "Lot đóng nhỏ hơn lot tối thiểu (" + DoubleToString(vmin, 2) + ")"; return false; }
      if(vol - closed < vmin - 1e-9)       { note = "Phần còn lại sẽ nhỏ hơn lot tối thiểu, hãy đóng hết"; return false; }
      ok = trade.PositionClosePartial(tk, closed);
   }
   else
      ok = trade.PositionClose(tk);
   uint rc = trade.ResultRetcode();
   if(!ok || (rc != TRADE_RETCODE_DONE && rc != TRADE_RETCODE_DONE_PARTIAL))
                                           { note = "Broker từ chối: " + trade.ResultRetcodeDescription(); return false; }
   note = StringFormat("Đã đóng %.2f lot %s #%s", closed, sym, ticketStr);
   return true;
}

void ReportCmd(const string id, const string status, const string note)
{
   string body = "{\"id\":\"" + id + "\",\"status\":\"" + status + "\",\"note\":\"" + JsonEsc(note) + "\"}";
   string resp;
   Http("POST", "/api/ea/command", body, resp);
}

void HandleCommand(const string obj)
{
   string id = JsonRaw(obj, "id");
   if(id == "" || IsDone(id)) return;
   MarkDone(id);
   string note;
   bool ok = ClosePos(JsonRaw(obj, "ticket"), StringToDouble(JsonRaw(obj, "volume")), note);
   PrintFormat("SignalBridge: đóng lệnh %s -> %s | %s", id, ok ? "done" : "rejected", note);
   ReportCmd(id, ok ? "done" : "rejected", note);
}

//------------------------------------------------------------------
// Giá trị 1 lot khi giá đi 1 đơn vị, theo tiền tài khoản (web dùng để ước tính P/L tại SL/TP)
//------------------------------------------------------------------
double PvOf(const string sym)
{
   double ts = SymbolInfoDouble(sym, SYMBOL_TRADE_TICK_SIZE);
   double tv = SymbolInfoDouble(sym, SYMBOL_TRADE_TICK_VALUE_PROFIT);
   if(tv <= 0) tv = SymbolInfoDouble(sym, SYMBOL_TRADE_TICK_VALUE);
   return ts > 0 ? tv / ts : 0;
}

//------------------------------------------------------------------
// Sửa SL/TP vị thế đang mở theo lệnh từ web (kéo line trên chart). 0 = gỡ.
// Không bị chặn bởi công tắc "Cho phép EA vào lệnh".
//------------------------------------------------------------------
bool ModifyPos(const string ticketStr, double sl, double tp, string &note)
{
   ulong tk = (ulong)StringToInteger(ticketStr);
   if(tk == 0 || !PositionSelectByTicket(tk))
                                           { note = "Không tìm thấy lệnh #" + ticketStr + " (có thể đã đóng)"; return false; }
   if(!TerminalInfoInteger(TERMINAL_TRADE_ALLOWED) || !MQLInfoInteger(MQL_TRADE_ALLOWED))
                                           { note = "Algo Trading đang tắt trong MT5"; return false; }
   string sym = PositionGetString(POSITION_SYMBOL);
   int    dg  = (int)SymbolInfoInteger(sym, SYMBOL_DIGITS);
   double point = SymbolInfoDouble(sym, SYMBOL_POINT);
   double minDist = SymbolInfoInteger(sym, SYMBOL_TRADE_STOPS_LEVEL) * point;
   bool   buy = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY);
   double cur = buy ? SymbolInfoDouble(sym, SYMBOL_BID) : SymbolInfoDouble(sym, SYMBOL_ASK);
   sl = NormalizeDouble(sl, dg);
   tp = NormalizeDouble(tp, dg);
   if(sl < 0 || tp < 0)                    { note = "SL/TP không hợp lệ"; return false; }
   if(sl > 0 && (buy ? !(sl < cur) : !(sl > cur))) { note = "SL nằm sai phía so với giá hiện tại"; return false; }
   if(tp > 0 && (buy ? !(tp > cur) : !(tp < cur))) { note = "TP nằm sai phía so với giá hiện tại"; return false; }
   if((sl > 0 && MathAbs(cur - sl) < minDist) || (tp > 0 && MathAbs(tp - cur) < minDist))
                                           { note = "SL/TP quá gần giá (stops level của broker)"; return false; }
   if(MathAbs(sl - PositionGetDouble(POSITION_SL)) < point / 2 && MathAbs(tp - PositionGetDouble(POSITION_TP)) < point / 2)
                                           { note = "SL/TP không đổi"; return true; }
   if(!trade.PositionModify(tk, sl, tp) || trade.ResultRetcode() != TRADE_RETCODE_DONE)
                                           { note = "Broker từ chối: " + trade.ResultRetcodeDescription(); return false; }
   note = StringFormat("Đã sửa #%s: SL %s | TP %s", ticketStr, DoubleToString(sl, dg), DoubleToString(tp, dg));
   return true;
}

void HandleModify(const string obj)
{
   string id = JsonRaw(obj, "id");
   if(id == "" || IsDone(id)) return;
   MarkDone(id);
   string note;
   bool ok = ModifyPos(JsonRaw(obj, "ticket"), StringToDouble(JsonRaw(obj, "sl")), StringToDouble(JsonRaw(obj, "tp")), note);
   PrintFormat("SignalBridge: sửa SL/TP %s -> %s | %s", id, ok ? "done" : "rejected", note);
   string body = "{\"id\":\"" + id + "\",\"status\":\"" + (ok ? "done" : "rejected") + "\",\"note\":\"" + JsonEsc(note) + "\"}";
   string resp;
   Http("POST", "/api/ea/modify", body, resp);
}

// Duyệt các object {...} trong 1 mảng JSON bắt đầu tại vị trí from. kind 0 = tín hiệu, 1 = lệnh đóng, 2 = lệnh sửa SL/TP.
// Trả về vị trí ngay sau dấu ']' đóng mảng.
int ForEachObj(const string s, const int from, const int kind)
{
   int depth = 0, start = -1, n = StringLen(s), i = from;
   bool inStr = false;
   for(; i < n; i++)
   {
      ushort c = StringGetCharacter(s, i);
      if(inStr)
      {
         if(c == '\\') { i++; continue; }
         if(c == '"') inStr = false;
         continue;
      }
      if(c == '"') { inStr = true; continue; }
      if(c == '{') { if(depth == 0) start = i; depth++; }
      else if(c == '}')
      {
         depth--;
         if(depth == 0 && start >= 0)
         {
            string o = StringSubstr(s, start, i - start + 1);
            if(kind == 0) HandleSignal(o); else if(kind == 1) HandleCommand(o); else HandleModify(o);
            start = -1;
         }
      }
      else if(c == ']' && depth == 0) break;
   }
   return i;
}

//------------------------------------------------------------------
// Vòng lặp chính
//------------------------------------------------------------------
void ProcessResponse(const string body)
{
   int ps = StringFind(body, "\"settings\":");
   int pg = StringFind(body, "\"signals\":[");
   if(ps < 0 || pg < 0) { g_status = "Phản hồi API không đúng định dạng"; Comment("Signal Bridge\n", g_status); return; }

   ParseCfg(StringSubstr(body, ps, pg - ps));
   g_status = "API OK | EA " + (g_cfg.enabled ? "BẬT" : "TẮT") + " | " + TimeToString(TimeCurrent(), TIME_SECONDS);
   Comment("Signal Bridge\n", g_status, "\nMã: ", g_cfg.symbolMap);

   int endSig = ForEachObj(body, pg + 11, 0);                         // tín hiệu vào lệnh
   int endCmd = endSig;
   int pc = StringFind(body, "\"commands\":[", endSig);
   if(pc >= 0) endCmd = ForEachObj(body, pc + 12, 1);                 // lệnh đóng vị thế từ web
   int pm = StringFind(body, "\"modifies\":[", endCmd);
   if(pm >= 0) ForEachObj(body, pm + 12, 2);                          // lệnh sửa SL/TP từ web (kéo line trên chart)
}

//------------------------------------------------------------------
// Dựng gói giá + vị thế gửi lên API (mỗi nhịp InpPollSec giây)
//------------------------------------------------------------------
string BuildLiveBar(const string sym)
{
   MqlRates fr[];
   if(sym == "" || CopyRates(sym, PERIOD_M1, 0, 1, fr) != 1) return "null";
   int bd = (int)SymbolInfoInteger(sym, SYMBOL_DIGITS);
   return "{\"symbol\":\"" + JsonEsc(sym) + "\",\"b\":[" + (string)(long)fr[0].time + "," + DoubleToString(fr[0].open, bd) + "," +
          DoubleToString(fr[0].high, bd) + "," + DoubleToString(fr[0].low, bd) + "," + DoubleToString(fr[0].close, bd) + "," + (string)fr[0].tick_volume + "]}";
}

string BuildQuoteBody()
{
   string lines[];
   int n = StringSplit(g_cfg.symbolMap, '\n', lines);
   string items = "";
   datetime firstT = 0;
   long     firstMsc = 0;
   string   seen = "";
   for(int i = 0; i < n; i++)
   {
      string kv[];
      if(StringSplit(lines[i], '=', kv) < 2) continue;
      string tk  = Trim(kv[0]);
      string sym = Trim(kv[1]);
      if(tk == "" || sym == "" || !SymbolSelect(sym, true)) continue;
      MqlTick t;
      if(!SymbolInfoTick(sym, t) || t.bid <= 0) continue;
      if(firstT == 0) { firstT = t.time; firstMsc = (long)t.time_msc; }
      int digits = (int)SymbolInfoInteger(sym, SYMBOL_DIGITS);
      long spread = SymbolInfoInteger(sym, SYMBOL_SPREAD);
      if(items != "") items += ",";
      items += "{\"ticker\":\"" + JsonEsc(tk) + "\",\"symbol\":\"" + JsonEsc(sym) + "\",\"bid\":" + DoubleToString(t.bid, digits) +
               ",\"ask\":" + DoubleToString(t.ask, digits) + ",\"spread\":" + (string)spread +
               ",\"tickTime\":" + (string)(long)t.time + ",\"dg\":" + (string)digits + ",\"pv\":" + DoubleToString(PvOf(sym), 4) + "}";
      seen += "|" + sym + "|";
   }
   // Các mã trong InpBarSymbol chưa có trong ánh xạ: vẫn gửi bid/ask (ticker = chính mã MT5) để web hiện giá và đặt lệnh tay được
   for(int k = 0; k < g_nss; k++)
   {
      string sym = g_ss[k].sym;
      if(StringFind(seen, "|" + sym + "|") >= 0 || !SymbolSelect(sym, true)) continue;
      MqlTick t;
      if(!SymbolInfoTick(sym, t) || t.bid <= 0) continue;
      if(firstT == 0) { firstT = t.time; firstMsc = (long)t.time_msc; }
      int digits = (int)SymbolInfoInteger(sym, SYMBOL_DIGITS);
      long spread = SymbolInfoInteger(sym, SYMBOL_SPREAD);
      if(items != "") items += ",";
      items += "{\"ticker\":\"" + JsonEsc(sym) + "\",\"symbol\":\"" + JsonEsc(sym) + "\",\"bid\":" + DoubleToString(t.bid, digits) +
               ",\"ask\":" + DoubleToString(t.ask, digits) + ",\"spread\":" + (string)spread +
               ",\"tickTime\":" + (string)(long)t.time + ",\"dg\":" + (string)digits + ",\"pv\":" + DoubleToString(PvOf(sym), 4) + "}";
      seen += "|" + sym + "|";
   }
   // Tuổi tick = số giây kể từ lần giá của mã đầu tiên thay đổi lần cuối, đo bằng đồng hồ chạy của máy (GetTickCount64).
   // KHÔNG dùng TimeTradeServer(): nó tính từ giờ PC nên PC lệch giờ vài phút là web báo "không có tick mới" oan.
   static long  s_msc = 0;
   static ulong s_chg = 0;
   if(firstT != 0 && firstMsc != s_msc) { s_msc = firstMsc; s_chg = GetTickCount64(); }
   long ageSec = (s_chg == 0) ? 0 : (long)((GetTickCount64() - s_chg) / 1000);
   long srvT   = (firstT == 0) ? (long)TimeCurrent() : (long)firstT + ageSec;
   // Nến M1 + footprint đang chạy dở của TỪNG mã (không ghi DB, chỉ đi kèm gói giá để web vẽ live).
   // "bar"/"fp" giữ lại cho mã đầu tiên (tương thích bản web cũ), "bars"/"fps" là danh sách đầy đủ.
   string bar = "null", fp = "null", bars = "", fps = "";
   for(int k = 0; k < g_nss; k++)
   {
      string b1 = BuildLiveBar(g_ss[k].sym), f1 = BuildLiveFp(g_ss[k]);
      if(k == 0) { bar = b1; fp = f1; }
      if(b1 != "null") bars += (bars == "" ? "" : ",") + b1;
      if(f1 != "null") fps  += (fps  == "" ? "" : ",") + f1;
   }
   string body = "{\"quotes\":[" + items + "],\"account\":{\"login\":" + (string)AccountInfoInteger(ACCOUNT_LOGIN) + ",\"balance\":" + DoubleToString(AccountInfoDouble(ACCOUNT_BALANCE), 2) +
                 ",\"equity\":" + DoubleToString(AccountInfoDouble(ACCOUNT_EQUITY), 2) +
                 ",\"ccy\":\"" + AccountInfoString(ACCOUNT_CURRENCY) + "\",\"open\":" + (string)CountOpen() + "},\"positions\":[" + BuildPositions() + "],\"serverTime\":" + (string)srvT + ",\"bar\":" + bar + ",\"fp\":" + fp + ",\"bars\":[" + bars + "],\"fps\":[" + fps + "]}";
   return body;
}

// 1 request mỗi chu kỳ: gửi giá + vị thế, nhận về tín hiệu + lệnh đóng + cài đặt
void Cycle()
{
   string resp;
   int code = Http("POST", "/api/ea/sync", BuildQuoteBody(), resp);
   if(code != 200)
   {
      g_status = "Lỗi kết nối API (mã " + (string)code + ")";
      Comment("Signal Bridge\n", g_status);
      return;
   }
   ProcessResponse(resp);
}

//------------------------------------------------------------------
// Đồng bộ lệnh ĐÃ ĐÓNG lên API (cho web nhật ký giao dịch)
// 1 position = 1 dòng. Gửi lại nhiều lần không sao vì server ghi đè theo khóa.
//------------------------------------------------------------------
datetime g_lastSync = 0;

bool IsSent(const ulong pid)
{
   for(int i = g_sentN - 1; i >= 0; i--) if(g_sentPid[i] == pid) return true;
   return false;
}
void MarkSent(const ulong pid)
{
   if(g_sentN >= 500)
   {
      for(int i = 1; i < g_sentN; i++) g_sentPid[i - 1] = g_sentPid[i];
      g_sentN--;
   }
   ArrayResize(g_sentPid, g_sentN + 1);
   g_sentPid[g_sentN++] = pid;
}
bool     g_syncNow  = false;   // đặt true khi có lệnh vừa đóng, OnTimer sẽ gửi ngay

string ReasonName(long r)
{
   switch((int)r)
   {
      case DEAL_REASON_SL:     return "sl";
      case DEAL_REASON_TP:     return "tp";
      case DEAL_REASON_SO:     return "stopout";
      case DEAL_REASON_CLIENT:
      case DEAL_REASON_MOBILE:
      case DEAL_REASON_WEB:    return "manual";
      case DEAL_REASON_EXPERT: return "expert";
   }
   return "other";
}

// Gộp mọi deal của 1 position thành 1 object JSON. Trả "" nếu position còn mở hoặc thiếu dữ liệu.
string BuildTrade(ulong pid)
{
   if(PositionSelectByTicket(pid)) return "";   // còn mở (kể cả đã chốt một phần) thì chờ đóng hẳn
   if(!HistorySelectByPosition(pid)) return "";
   int n = HistoryDealsTotal();
   double vin = 0, pin = 0, vout = 0, pout = 0, profit = 0, comm = 0, swap = 0, fee = 0, sl = 0, tp = 0;
   datetime tIn = 0, tOut = 0;
   string sym = "", cmt = "", side = "buy";
   long magic = 0, reason = 0;
   for(int i = 0; i < n; i++)
   {
      ulong d = HistoryDealGetTicket(i);
      if(d == 0) continue;
      long type = HistoryDealGetInteger(d, DEAL_TYPE);
      if(type != DEAL_TYPE_BUY && type != DEAL_TYPE_SELL) continue;   // bỏ deal nạp/rút, balance...
      long   en = HistoryDealGetInteger(d, DEAL_ENTRY);
      double v  = HistoryDealGetDouble(d, DEAL_VOLUME);
      double p  = HistoryDealGetDouble(d, DEAL_PRICE);
      datetime t = (datetime)HistoryDealGetInteger(d, DEAL_TIME);
      profit += HistoryDealGetDouble(d, DEAL_PROFIT);
      comm   += HistoryDealGetDouble(d, DEAL_COMMISSION);
      swap   += HistoryDealGetDouble(d, DEAL_SWAP);
      fee    += HistoryDealGetDouble(d, DEAL_FEE);
      if(en == DEAL_ENTRY_IN)
      {
         pin = (vin * pin + v * p) / (vin + v);
         vin += v;
         if(tIn == 0 || t < tIn)
         {
            tIn = t;
            sym = HistoryDealGetString(d, DEAL_SYMBOL);
            cmt = HistoryDealGetString(d, DEAL_COMMENT);
            side = (type == DEAL_TYPE_BUY) ? "buy" : "sell";
            magic = HistoryDealGetInteger(d, DEAL_MAGIC);
            sl = HistoryDealGetDouble(d, DEAL_SL);
            tp = HistoryDealGetDouble(d, DEAL_TP);
         }
      }
      else if(en == DEAL_ENTRY_OUT || en == DEAL_ENTRY_OUT_BY)
      {
         pout = (vout * pout + v * p) / (vout + v);
         vout += v;
         if(t >= tOut) { tOut = t; reason = HistoryDealGetInteger(d, DEAL_REASON); }
      }
   }
   if(vin <= 0 || vout <= 0) return "";
   return "{\"pos\":\"" + (string)pid + "\",\"symbol\":\"" + JsonEsc(sym) + "\",\"side\":\"" + side +
          "\",\"volume\":" + DoubleToString(vin, 4) +
          ",\"openTime\":" + (string)(long)tIn + ",\"closeTime\":" + (string)(long)tOut +
          ",\"openPrice\":" + DoubleToString(pin, 8) + ",\"closePrice\":" + DoubleToString(pout, 8) +
          ",\"sl\":" + DoubleToString(sl, 8) + ",\"tp\":" + DoubleToString(tp, 8) +
          ",\"profit\":" + DoubleToString(profit, 2) + ",\"commission\":" + DoubleToString(comm, 2) +
          ",\"swap\":" + DoubleToString(swap, 2) + ",\"fee\":" + DoubleToString(fee, 2) +
          ",\"magic\":" + (string)magic + ",\"comment\":\"" + JsonEsc(cmt) + "\",\"reason\":\"" + ReasonName(reason) + "\"}";
}

void SyncDeals()
{
   const string gv = "SB_SYNC_T";                    // mốc đã đồng bộ xong (lưu bền trong terminal)
   datetime now = TimeCurrent();
   datetime from = GlobalVariableCheck(gv) ? (datetime)(long)GlobalVariableGet(gv) - 3600       // chồng 1 giờ cho chắc
                                           : now - (datetime)InpBackfillDays * 86400;
   if(!HistorySelect(from, now + 60)) return;

   ulong pids[];
   int total = HistoryDealsTotal();
   for(int i = 0; i < total; i++)
   {
      ulong d = HistoryDealGetTicket(i);
      if(d == 0) continue;
      long en = HistoryDealGetInteger(d, DEAL_ENTRY);
      if(en != DEAL_ENTRY_OUT && en != DEAL_ENTRY_OUT_BY) continue;
      ulong pid = (ulong)HistoryDealGetInteger(d, DEAL_POSITION_ID);
      if(pid == 0) continue;
      bool dup = false;
      for(int k = ArraySize(pids) - 1; k >= 0; k--) if(pids[k] == pid) { dup = true; break; }
      if(!dup && !IsSent(pid)) { int s = ArraySize(pids); ArrayResize(pids, s + 1); pids[s] = pid; }
   }

   int np = ArraySize(pids);
   long off = (long)MathRound((double)(TimeTradeServer() - TimeGMT()) / 900.0) * 900;   // lệch giờ server so với UTC (giây)
   string acct = (string)AccountInfoInteger(ACCOUNT_LOGIN);
   string items = "", resp;
   int cnt = 0, sent = 0;
   bool allOk = true;
   ulong chunk[];
   for(int k = 0; k < np; k++)
   {
      string t = BuildTrade(pids[k]);                // đổi vùng history đang chọn, nên danh sách pids đã lấy xong ở trên
      if(t != "") { items += (items == "" ? "" : ",") + t; cnt++; ArrayResize(chunk, cnt); chunk[cnt - 1] = pids[k]; }
      if(cnt > 0 && (cnt >= 20 || k == np - 1))
      {
         string body = "{\"account\":\"" + acct + "\",\"tzOffset\":" + (string)off + ",\"trades\":[" + items + "]}";
         if(Http("POST", "/api/ea/deals", body, resp) != 200) { allOk = false; break; }
         for(int q = 0; q < cnt; q++) MarkSent(chunk[q]);
         sent += cnt; cnt = 0; items = "";
      }
   }
   if(allOk) GlobalVariableSet(gv, (double)now);
   if(sent > 0) PrintFormat("SignalBridge: đã đồng bộ %d lệnh đã đóng lên API", sent);
}

// Khi có deal ĐÓNG vị thế (SL/TP/đóng tay/EA đóng) thì gửi ngay, không đợi nhịp 30 giây.
// Lệnh chờ Limit/Stop chưa khớp hoặc bị hủy không tạo deal nên không bao giờ được gửi.
void OnTradeTransaction(const MqlTradeTransaction &trans, const MqlTradeRequest &req, const MqlTradeResult &res)
{
   if(trans.type != TRADE_TRANSACTION_DEAL_ADD) return;
   if(!HistoryDealSelect(trans.deal)) return;
   long en = HistoryDealGetInteger(trans.deal, DEAL_ENTRY);
   if(en == DEAL_ENTRY_OUT || en == DEAL_ENTRY_OUT_BY) g_syncNow = true;
}

//------------------------------------------------------------------
// Nến M1 ĐÃ ĐÓNG lên API (cho web TPO). Gửi lại nến cuối mỗi lần nên không mất nến, server ghi đè theo khóa.
//------------------------------------------------------------------
bool SyncBars(SymSt &s)
{
   if(s.sym == "" || !SymbolSelect(s.sym, true)) return false;
   string gv = "SB_BAR_T_" + s.sym, gd = "SB_BAR_DAYS_" + s.sym;   // trạng thái lưu riêng cho từng mã
   if(!s.barInit)
   {
      s.barInit = true;
      if(GlobalVariableCheck(gv)) s.barSentT = (datetime)(long)GlobalVariableGet(gv);
      // Nếu InpBarDays lớn hơn số ngày đã backfill lần trước (hoặc chưa từng ghi nhận) thì bỏ mốc cũ, gửi bù lại từ đầu.
      // Nhờ vậy khỏi phải xóa SB_BAR_T ở F3. Server ghi đè theo khóa (symbol, t) nên gửi lại không bị trùng.
      if(!GlobalVariableCheck(gd) || GlobalVariableGet(gd) < InpBarDays - 0.5)
      {
         s.barSentT = 0;
         PrintFormat("SignalBridge: backfill lại nến M1 %d ngày (%s).", InpBarDays, s.sym);
      }
   }
   datetime cur = iTime(s.sym, PERIOD_M1, 0);
   if(cur == 0) return false;
   if(cur == s.barSeenT) return true;                       // chưa có nến mới
   datetime floorT = cur - (datetime)InpBarDays * 86400;
   datetime from = (s.barSentT > floorT) ? s.barSentT : floorT;

   // Backfill lần đầu của 1 mã: MT5 chỉ tải lịch sử mã đó từ broker khi được yêu cầu. Gọi CopyRates ngay thì thường chỉ nhận vài nến đang có sẵn,
   // EA tưởng đã xong rồi không gửi bù nữa. Nên chờ lịch sử M1 đồng bộ xong (thử mỗi 5 giây, tối đa ~1 phút) rồi mới gửi lần đầu.
   if(s.barSentT == 0 && s.barWait < 12)
   {
      MqlRates tmp[];
      CopyRates(s.sym, PERIOD_M1, floorT, 1, tmp);                                   // yêu cầu MT5 tải lịch sử từ server
      bool     synced = (bool)SeriesInfoInteger(s.sym, PERIOD_M1, SERIES_SYNCHRONIZED);
      datetime lf     = (datetime)SeriesInfoInteger(s.sym, PERIOD_M1, SERIES_FIRSTDATE);          // nến cũ nhất đang có trong máy
      datetime sf     = (datetime)SeriesInfoInteger(s.sym, PERIOD_M1, SERIES_SERVER_FIRSTDATE);   // nến cũ nhất broker có
      datetime want   = (sf > floorT) ? sf : floorT;
      if(!synced || lf == 0 || lf > want + 3 * 86400)                                // dư 3 ngày cho cuối tuần/nghỉ lễ
      {
         if(++s.barWait == 1) PrintFormat("SignalBridge: %s đang tải lịch sử M1 từ broker, chờ rồi gửi bù...", s.sym);
         return false;
      }
   }

   MqlRates r[];
   int n = CopyRates(s.sym, PERIOD_M1, from, cur - 1, r);   // chỉ nến đã đóng
   if(n <= 0) return false;                                  // lịch sử chưa tải xong, lần sau thử lại

   int dg = (int)SymbolInfoInteger(s.sym, SYMBOL_DIGITS);
   string head = "{\"symbol\":\"" + JsonEsc(s.sym) + "\",\"bars\":[";
   string resp;
   for(int i = 0; i < n; i += 300)
   {
      string items = "";
      int e = MathMin(n, i + 300);
      for(int k = i; k < e; k++)
         items += (k > i ? "," : "") + "[" + (string)(long)r[k].time + "," + DoubleToString(r[k].open, dg) + "," + DoubleToString(r[k].high, dg) + "," +
                  DoubleToString(r[k].low, dg) + "," + DoubleToString(r[k].close, dg) + "," + (string)r[k].tick_volume + "]";
      if(Http("POST", "/api/ea/bars", head + items + "]}", resp) != 200) return false;
   }
   s.barSentT = r[n - 1].time;
   s.barSeenT = cur;
   GlobalVariableSet(gv, (double)s.barSentT);
   GlobalVariableSet(gd, (double)InpBarDays);   // đã backfill xong số ngày này
   if(n > 10) PrintFormat("SignalBridge: đã gửi %d nến M1 %s lên API", n, s.sym);
   return true;
}

//------------------------------------------------------------------
// FOOTPRINT: gộp tick thành khối lượng MUA/BÁN theo từng mức giá cho mỗi phút
// - Mã có aggressor thật (futures/cổ phiếu): dùng TICK_FLAG_BUY/SELL + volume_real
// - Mã CFD/forex (XAUUSD...): không có giao dịch thật, phân loại theo tick-rule:
//     ask hoặc bid tăng => MUA, giảm => BÁN, không đổi => giữ hướng cũ. Khối lượng = 1 tick.
// Giá dùng là BID (khớp với nến M1 của MT5).
//------------------------------------------------------------------

string FpNum(const double x)
{
   if(MathAbs(x - MathRound(x)) < 1e-9) return IntegerToString((long)MathRound(x));
   return DoubleToString(x, 2);
}

// Gộp tick trong [fromMsc, toMsc] thành chuỗi JSON [[giá,mua,bán],...]. st được cập nhật (truyền bản sao nếu chỉ xem thử).
// Trả về số tick đã gộp, -1 nếu lỗi.
int FpAgg(const string sym, const long fromMsc, const long toMsc, FpState &st, string &out)
{
   out = "[]";
   MqlTick tk[];
   ResetLastError();
   int n = CopyTicksRange(sym, tk, COPY_TICKS_ALL, (ulong)fromMsc, (ulong)toMsc);
   if(n < 0) return -1;
   if(n == 0) return 0;
   double pt = SymbolInfoDouble(sym, SYMBOL_POINT);
   int dg = (int)SymbolInfoInteger(sym, SYMBOL_DIGITS);
   if(pt <= 0) return -1;

   long    pi[]; int sd[]; double vv[];
   ArrayResize(pi, n); ArrayResize(sd, n); ArrayResize(vv, n);
   long mn = 0, mx = 0; bool any = false; int used = 0;
   for(int i = 0; i < n; i++)
   {
      sd[i] = 0; vv[i] = 1;
      bool fb = (tk[i].flags & TICK_FLAG_BUY) != 0, fs = (tk[i].flags & TICK_FLAG_SELL) != 0;
      int side = 0; double px = tk[i].bid;
      if(fb != fs && tk[i].last > 0)                    // giao dịch thật có aggressor
      {
         side = fb ? 1 : -1; px = tk[i].last;
         vv[i] = (tk[i].volume_real > 0) ? tk[i].volume_real : (tk[i].volume > 0 ? (double)tk[i].volume : 1);
      }
      else if(tk[i].bid > 0)                            // tick-rule trên bid/ask
      {
         if(st.bid > 0)
         {
            double db = tk[i].bid - st.bid, da = tk[i].ask - st.ask;
            if((da > 0 && db >= 0) || (db > 0 && da >= 0)) side = 1;
            else if((da < 0 && db <= 0) || (db < 0 && da <= 0)) side = -1;
            else side = st.side;                        // không đổi hoặc spread giãn: giữ hướng cũ
         }
      }
      if(tk[i].bid > 0) { st.bid = tk[i].bid; st.ask = tk[i].ask; }
      if(side != 0) st.side = side;
      if(side == 0 || px <= 0) continue;
      pi[i] = (long)MathRound(px / pt); sd[i] = side; used++;
      if(!any) { mn = mx = pi[i]; any = true; } else { if(pi[i] < mn) mn = pi[i]; if(pi[i] > mx) mx = pi[i]; }
   }
   if(!any) return 0;
   if(mx - mn > 50000) return -1;
   int m = (int)(mx - mn) + 1;
   double b[], s[]; ArrayResize(b, m); ArrayResize(s, m); ArrayInitialize(b, 0); ArrayInitialize(s, 0);
   for(int i = 0; i < n; i++)
   {
      if(sd[i] == 0) continue;
      int k = (int)(pi[i] - mn);
      if(sd[i] > 0) b[k] += vv[i]; else s[k] += vv[i];
   }
   string o = "[";
   bool first = true;
   for(int k = 0; k < m; k++)
   {
      if(b[k] <= 0 && s[k] <= 0) continue;
      o += (first ? "" : ",") + "[" + DoubleToString((double)(mn + k) * pt, dg) + "," + FpNum(b[k]) + "," + FpNum(s[k]) + "]";
      first = false;
   }
   out = o + "]";
   return used;
}

// Phút đang chạy: tính lại mỗi giây từ đầu phút, đi kèm gói giá (không ghi DB)
string BuildLiveFp(SymSt &s)
{
   if(!InpFpOn || s.sym == "") return "null";
   datetime cur = iTime(s.sym, PERIOD_M1, 0);
   if(cur == 0) return "null";
   FpState st = s.fps;
   string r;
   int c = FpAgg(s.sym, (long)cur * 1000, (long)(cur + 60) * 1000 - 1, st, r);
   if(c < 0) return "null";
   return "{\"symbol\":\"" + JsonEsc(s.sym) + "\",\"t\":" + (string)(long)cur + ",\"n\":" + (string)c + ",\"r\":" + r + "}";
}

// Gửi các phút [t0, t1) lên API, mỗi lần tối đa 20 phút có dữ liệu và quét tối đa 60 phút (kỳ nghỉ dài không làm treo EA).
// done = phút cuối cùng đã xử lý xong (0 nếu chưa xong phút nào). Trả false nếu cần thử lại ở nhịp sau.
bool FpSendRange(SymSt &s, const datetime t0, const datetime t1, FpState &st, datetime &done)
{
   string items = "", r, resp;
   int cnt = 0, scanned = 0;
   done = 0;
   for(datetime t = t0; t < t1 && cnt < 20 && scanned < 60; t += 60)
   {
      scanned++;
      int c = FpAgg(s.sym, (long)t * 1000, (long)(t + 60) * 1000 - 1, st, r);
      if(c < 0)                                                 // lịch sử tick chưa sẵn sàng: thử lại vài lần rồi BỎ QUA phút đó, không kẹt mãi
      {
         if(s.fpSkipT != t) { s.fpSkipT = t; s.fpFail = 0; }
         if(++s.fpFail < 3) return false;
         PrintFormat("SignalBridge: bỏ qua footprint phút %s (không đọc được tick, lỗi %d)", TimeToString(t), GetLastError());
         s.fpFail = 0; done = t; continue;
      }
      done = t;
      if(c == 0) continue;
      items += (items == "" ? "" : ",") + "{\"t\":" + (string)(long)t + ",\"r\":" + r + "}";
      cnt++;
   }
   if(items != "")
   {
      string body = "{\"symbol\":\"" + JsonEsc(s.sym) + "\",\"mins\":[" + items + "]}";
      if(Http("POST", "/api/ea/fp", body, resp) != 200) { st.bid = 0; done = 0; return false; }
   }
   return true;
}

// 1) Chạy TIẾN: các phút vừa đóng (luôn ưu tiên, nên footprint mới nhất không bao giờ bị trễ vì đang gửi bù).
// 2) Khi đã bắt kịp thì gửi bù LÙI từng đoạn 20 phút về quá khứ, từ mới đến cũ, cho tới InpFpDays ngày.
bool SyncFp(SymSt &s)
{
   if(s.sym == "" || !SymbolSelect(s.sym, true)) return false;
   if(!s.fpInit)
   {
      s.fpInit = true;
      s.fps.bid = 0; s.fps.ask = 0; s.fps.side = 0;
      if(GlobalVariableCheck("SB_FP_T_" + s.sym))    s.fpSentT = (datetime)(long)GlobalVariableGet("SB_FP_T_" + s.sym);
      if(GlobalVariableCheck("SB_FP_BACK_" + s.sym)) s.fpBackT = (datetime)(long)GlobalVariableGet("SB_FP_BACK_" + s.sym);
      else if(s.fpSentT > 0)                s.fpBackT = s.fpSentT;   // nâng cấp từ bản cũ: quét ngược lại toàn bộ để vá các phút còn thiếu
   }
   datetime cur = iTime(s.sym, PERIOD_M1, 0);
   if(cur == 0) return false;
   if(s.fpSentT == 0) s.fpSentT = cur - 120;
   if(s.fpBackT == 0) s.fpBackT = cur - 60;
   datetime floorT = cur - (datetime)InpFpDays * 86400;
   floorT -= floorT % 60;
   datetime done = 0;

   datetime f0 = s.fpSentT + 60;
   if(f0 < floorT) f0 = floorT;
   f0 -= f0 % 60;
   if(f0 < cur)
   {
      if(!FpSendRange(s, f0, cur, s.fps, done)) return false;
      if(done > 0) { s.fpSentT = done; GlobalVariableSet("SB_FP_T_" + s.sym, (double)s.fpSentT); }
      return true;
   }
   if(s.fpBackT > floorT)
   {
      datetime e = s.fpBackT, st0 = e - 20 * 60;
      if(st0 < floorT) st0 = floorT;
      st0 -= st0 % 60;
      FpState st; st.bid = 0; st.ask = 0; st.side = 0;
      if(!FpSendRange(s, st0, e, st, done)) return false;
      if(done >= e - 60)
      {
         s.fpBackT = st0;
         GlobalVariableSet("SB_FP_BACK_" + s.sym, (double)s.fpBackT);
         static int n = 0;
         if(++n % 50 == 0) PrintFormat("SignalBridge: gửi bù footprint, đã lùi tới %s", TimeToString(s.fpBackT));
      }
   }
   return true;
}

int OnInit()
{
   g_apiUrl = Trim(InpApiUrl);
   while(StringLen(g_apiUrl) > 0 && StringGetCharacter(g_apiUrl, StringLen(g_apiUrl) - 1) == '/')
      g_apiUrl = StringSubstr(g_apiUrl, 0, StringLen(g_apiUrl) - 1);
   if(StringFind(g_apiUrl, "https://") != 0 || InpToken == "")
   {
      Alert("SignalBridge: cần nhập API URL (bắt đầu bằng https://) và Secret token.");
      return INIT_PARAMETERS_INCORRECT;
   }
   if(AccountInfoInteger(ACCOUNT_MARGIN_MODE) != ACCOUNT_MARGIN_MODE_RETAIL_HEDGING)
      Print("SignalBridge: cảnh báo, tài khoản không phải hedging, EA được viết cho hedging.");
   ParseCfg("{}");
   // Danh sách mã cho chart/TPO/footprint (cách nhau bằng dấu phẩy hoặc chấm phẩy)
   string lst = InpBarSymbol;
   StringReplace(lst, ";", ",");
   string parts[];
   int pn = StringSplit(lst, ',', parts);
   ArrayResize(g_ss, 0);
   g_nss = 0;
   for(int i = 0; i < pn; i++)
   {
      string sy = Trim(parts[i]);
      if(sy == "") continue;
      bool dup = false;
      for(int j = 0; j < g_nss; j++) if(g_ss[j].sym == sy) dup = true;
      if(dup) continue;
      ArrayResize(g_ss, g_nss + 1);
      g_ss[g_nss].sym = sy;
      g_ss[g_nss].barSentT = 0; g_ss[g_nss].barSeenT = 0; g_ss[g_nss].barRetry = 0; g_ss[g_nss].barInit = false; g_ss[g_nss].barWait = 0;
      g_ss[g_nss].fps.bid = 0;  g_ss[g_nss].fps.ask = 0;  g_ss[g_nss].fps.side = 0;
      g_ss[g_nss].fpSentT = 0;  g_ss[g_nss].fpBackT = 0;  g_ss[g_nss].fpRetry = 0;  g_ss[g_nss].fpSkipT = 0;
      g_ss[g_nss].fpInit = false; g_ss[g_nss].fpFail = 0;
      g_nss++;
      if(!SymbolSelect(sy, true))
         PrintFormat("SignalBridge: KHÔNG tìm thấy mã '%s' ở broker. Kiểm tra InpBarSymbol (đúng hoa/thường và hậu tố như + hoặc .m, xem trong Market Watch > Symbols).", sy);
   }
   if(g_nss == 0) Print("SignalBridge: InpBarSymbol đang trống, sẽ không gửi nến/footprint lên web.");
   else PrintFormat("SignalBridge: gửi nến M1%s cho %d mã: %s", InpFpOn ? " + footprint" : "", g_nss, lst);
   EventSetTimer(1);   // timer luôn 1 giây, nhịp gọi API do OnTimer tự điều chỉnh
   PrintFormat("SignalBridge chạy. Nhớ thêm %s vào danh sách WebRequest cho phép.", g_apiUrl);
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason)
{
   EventKillTimer();
   Comment("");
}

void OnTimer()
{
   ManageBreakEven();                                  // chạy cục bộ mỗi giây, không tốn request
   if(++g_tickCnt >= MathMax(1, InpPollSec))                // luôn gọi đều mỗi InpPollSec giây (mặc định 1)
   {
      g_tickCnt = 0;
      Cycle();
   }
   for(int k = 0; k < g_nss; k++)                      // mỗi mã có con trỏ tiến độ và lịch thử lại riêng
   {
      if(TimeLocal() >= g_ss[k].barRetry && !SyncBars(g_ss[k])) g_ss[k].barRetry = TimeLocal() + 5;   // nến M1 cho TPO, lỗi thì thử lại sau 5 giây
      if(InpFpOn && TimeLocal() >= g_ss[k].fpRetry && !SyncFp(g_ss[k])) g_ss[k].fpRetry = TimeLocal() + 5;   // footprint (tick -> mua/bán theo giá)
   }
   if(g_syncNow || (InpSyncSec > 0 && TimeLocal() - g_lastSync >= InpSyncSec))   // đóng lệnh là gửi ngay; ngoài ra quét định kỳ cho chắc
   {
      g_syncNow = false;
      g_lastSync = TimeLocal();
      SyncDeals();
   }
}

void OnTick() { }
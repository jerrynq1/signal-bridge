/* ================= LỆNH TAY: BUY / SELL gửi về EA ================= */
$("oLot").value=ld("tp_lot","0.01");
let toastT=0,ordBusy=false;
/* Khóa chống trùng (cid): cùng một lệnh gửi lại sau khi rớt mạng sẽ dùng LẠI cùng cid nên server không tạo lệnh thứ hai.
   Chỉ dùng lại khi nội dung lệnh y hệt và chưa quá 2 phút; lệnh khác nội dung thì luôn là cid mới. */
let CIDM=null;
const newCid=()=>(crypto.randomUUID?crypto.randomUUID():Date.now().toString(16)+"-"+Math.random().toString(16).slice(2,12));
function cidFor(body){const{px,...rest}=body,fp=JSON.stringify(rest);   /* px đổi theo từng tick nên không đưa vào dấu vân tay */
  if(CIDM&&CIDM.fp===fp&&Date.now()-CIDM.t<120000)return CIDM.cid;CIDM={fp,cid:newCid(),t:Date.now(),lane:null};return CIDM.cid}
function toast(msg,cls,ms){const e=$("toast");e.textContent=msg;e.className="on "+(cls||"");clearTimeout(toastT);if(ms)toastT=setTimeout(()=>{e.className=""},ms)}
const setOrdBtns=on=>{$("oBuy").disabled=on;$("oSell").disabled=on};
function confirmOrder(side,lot,sym,sl,tp,pend){
  return new Promise(res=>{
    const o=document.createElement("div"),back=document.activeElement,buy=side==="buy";
    o.className="mdl";o.setAttribute("role","dialog");o.setAttribute("aria-modal","true");o.setAttribute("aria-labelledby","ordT");
    o.innerHTML='<div class="box"><header><h3 id="ordT">Xác nhận vào lệnh</h3></header><div class="bd"><p id="ordP" style="font-size:17px;font-weight:700;margin:6px 0 10px"></p><p class="msg" id="ordS" style="margin:0"></p></div><footer><span style="flex:1"></span><button class="btn ghost sm" type="button" data-r="0">Hủy</button><button class="btn sm" type="button" data-r="1" id="ordOk">Xác nhận</button></footer></div>';
    const P=o.querySelector("#ordP"),ok=o.querySelector("#ordOk");
    P.textContent=pend?"Đặt lệnh chờ "+pend.kind.replace("_"," ").toUpperCase()+" "+lot+" lot "+sym+" tại giá "+pend.price+".":"Vào lệnh "+side.toUpperCase()+" "+lot+" lot "+sym+" theo giá thị trường.";
    P.style.color=buy?"var(--win)":"var(--loss)";
    o.querySelector("#ordS").textContent="SL: "+(sl||"—")+" · TP: "+(tp||"—");
    ok.style.background=buy?"linear-gradient(135deg,#0fb37f,#3df5c0)":"linear-gradient(135deg,#ff5c8a,#d6336c)";
    ok.style.color=buy?"#04221a":"#fff";
    const kd=e=>{if(e.key==="Escape"){e.preventDefault();done(false)}};
    const done=v=>{o.remove();document.removeEventListener("keydown",kd,true);if(back&&back.isConnected&&back.focus)back.focus();res(v)};
    document.addEventListener("keydown",kd,true);
    o.onclick=e=>{if(e.target===o)return done(false);const b=e.target.closest("[data-r]");if(b)done(b.dataset.r==="1")};
    document.body.append(o);ok.focus();
  });
}
/* Đọc và kiểm tra lot / SL / TP / giá hiện tại; lỗi thì báo toast và trả null */
function readOrderInputs(){
  if(ordBusy)return null;
  if(!C.url||!C.token){toast("Chưa nhập API ở mục Kết nối.","bad",5000);return null}
  const lot=parseFloat($("oLot").value);
  if(!(lot>0)){toast("Nhập lot hợp lệ (lớn hơn 0).","bad",4000);$("oLot").focus();return null}
  const slS=$("oSl").value.trim(),tpS=$("oTp").value.trim(),sl=slS?parseFloat(slS):0,tp=tpS?parseFloat(tpS):0;
  if((slS&&!(sl>0))||(tpS&&!(tp>0))){toast("SL/TP phải là số dương.","bad",4000);return null}
  const bid=parseFloat($("bid").textContent),ask=parseFloat($("ask").textContent);
  if(!(bid>0&&ask>0)){toast("Chưa có giá từ EA, chưa thể vào lệnh.","bad",4000);return null}
  if(typeof AGEMS!=="undefined"&&AGEMS>15000){toast("Giá từ EA đã cũ "+Math.round(AGEMS/1000)+" giây (EA mất kết nối hoặc thị trường đóng cửa). Không gửi lệnh theo giá cũ.","bad",6000);return null}
  return{lot,sl,tp,bid,ask}
}
async function sendOrder(side){
  const q=readOrderInputs();if(!q)return;
  const{lot,sl,tp,bid,ask}=q;
  if(side==="buy"?((sl&&sl>=ask)||(tp&&tp<=ask)):((sl&&sl<=bid)||(tp&&tp>=bid))){toast("SL/TP nằm sai phía so với giá hiện tại","bad",5000);return}
  runOrder({action:side,ticker:C.sym,lot,sl,tp,px:side==="buy"?ask:bid},null);   // px = giá đang thấy; EA từ chối nếu giá thật đã lệch quá mức "Lệch giá tối đa" 
}
/* Lệnh chờ (chuột phải / nút "+"): kind = buy_limit | sell_limit | buy_stop | sell_stop
   Gửi POST /api/orders {action:kind, ticker, lot, price, sl, tp}. Worker + EA phải hỗ trợ các action này. */
async function placePending(kind,price){
  const q=readOrderInputs();if(!q)return;
  const{lot,sl,tp,bid,ask}=q,buy=kind.startsWith("buy");
  const okP=kind==="buy_limit"?price<ask:kind==="sell_limit"?price>bid:kind==="buy_stop"?price>ask:kind==="sell_stop"?price<bid:false;
  if(!okP){toast("Giá đặt lệnh chờ nằm sai phía so với giá hiện tại","bad",5000);return}
  if(buy?((sl&&sl>=price)||(tp&&tp<=price)):((sl&&sl<=price)||(tp&&tp>=price))){toast("SL/TP nằm sai phía so với giá đặt lệnh","bad",5000);return}
  runOrder({action:kind,ticker:C.sym,lot,price,sl,tp},{kind,price});
}
async function runOrder(body,pend){
  const{action,lot,sl,tp,ticker:sym}=body,side=pend?(action.startsWith("buy")?"buy":"sell"):action;
  if(!await confirmOrder(side,lot,sym,sl,tp,pend))return;
  ordBusy=true;setOrdBtns(true);sv("tp_lot",lot);
  let sentId=null,call=api,lane=false;
  try{
    toast("Đang gửi lệnh…","",0);
    const full=Object.assign({cid:cidFor(body)},body);
    /* Đường đi (nhanh hay Worker) được CHỐT một lần theo cid: gửi lại cùng lệnh trong 2 phút luôn đi đúng đường cũ,
       vì server local và Worker không biết cid của nhau, đổi đường giữa chừng có thể vào lệnh đôi. */
    lane=CIDM.lane!=null?CIDM.lane:laneOn();CIDM.lane=lane;
    let r;
    if(lane){
      try{r=await lapi("POST","/api/orders",full,8000)}
      catch(e){
        if(e.status===503&&(e.code==="ea_down"||e.code==="cfg_stale")){lane=false;CIDM.lane=false;r=await api("POST","/api/orders",full)}   /* 503 = server local CHƯA nhận lệnh, gửi qua Worker là an toàn */
        else throw e}
    }else r=await api("POST","/api/orders",full);
    call=lane?lapi:api;
    if(r.status==="rejected"){toast("EA từ chối: "+r.note,"bad",8000);CIDM=null;return}
    sentId=r.id;
    if(r.dup)toast("Lệnh này đã được gửi trước đó (không tạo lệnh trùng). Đang theo dõi kết quả…","",0);
    const ttl=((cfgOk&&+cfg.expirySec)||60)*1000+5000,t0=Date.now();
    for(;;){
      await new Promise(z=>setTimeout(z,lane?60:600));
      const s=await call("GET","/api/orders?id="+encodeURIComponent(sentId));
      if(s.status==="executed"||s.status==="placed"){CIDM=null;toast((pend?"Đã đặt lệnh chờ: ":"Đã vào lệnh: ")+s.note+(lane?" ⚡ "+(Date.now()-t0)+"ms":""),"ok",8000);$("oSl").value="";$("oTp").value="";return}
      if(s.status==="rejected"){CIDM=null;toast("EA từ chối: "+s.note,"bad",8000);return}
      if(s.status==="expired"){toast("EA không phản hồi kịp, lệnh đã bị hủy. Kiểm tra EA có đang chạy không.","bad",9000);CIDM=null;return}
      if(s.status==="unknown"){toast("Lệnh đã giao cho EA nhưng chưa có xác nhận. KHÔNG biết đã vào lệnh hay chưa, hãy xem bảng lệnh đang mở / MT5 trước khi gửi lại.","bad",12000);return}
      if(Date.now()-t0>ttl){toast("Chưa có phản hồi từ EA. Kiểm tra EA rồi xem lại ở Journal trước khi gửi lại.","bad",9000);return}
    }
  }catch(e){
    if(sentId)toast("Mất kết nối khi chờ phản hồi. Lệnh có thể đã được gửi, hãy kiểm tra Journal trước khi gửi lại.","bad",10000);
    else if(lane)toast("Không gọi được server local: "+why(e)+". Lệnh có thể đã vào hàng đợi, hãy kiểm tra MT5 trước. Gửi lại y hệt trong 2 phút vẫn đi đường nhanh (không tạo lệnh trùng); sau 2 phút sẽ đi đường dự phòng.","bad",11000);
    else toast("Không gửi được lệnh: "+why(e)+". Nếu bấm gửi lại ngay lệnh y hệt, hệ thống sẽ không tạo lệnh trùng.","bad",9000);
  }
  finally{ordBusy=false;setOrdBtns(false)}
}
$("oBuy").onclick=()=>sendOrder("buy");
$("oSell").onclick=()=>sendOrder("sell");

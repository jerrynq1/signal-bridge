/* ================= EA SETTING (giữ nguyên từ Signal Bridge) ================= */
const DEF={enabled:false,symbolMap:"XAUUSD=XAUUSD.pc",allowLong:true,allowShort:true,lotMode:"fixed",lot:0.01,riskPct:1,maxTradesDay:3,maxOpen:1,maxSpread:40,slippage:30,magic:20261016,priceMode:"distance",offset:0,tpMode:"strategy",rr:2,beAtR:0,useSession:false,sessFrom:"07:00",sessTo:"22:00",expirySec:60,pendingMin:0,maxLot:1,maxDev:0};
const FIELDS=[
 ["Mã giao dịch",[
  ["symbolMap","Ánh xạ mã TV = mã MT5","area","Mỗi dòng một cặp. Tên mã MT5 phải đúng với broker (có thể là XAUUSD, GOLD, XAUUSD.m…)."],
  ["allowLong","Cho phép LONG","bool"],["allowShort","Cho phép SHORT","bool"]]],
 ["Khối lượng",[
  ["lotMode","Cách tính lot","sel",{fixed:"Lot cố định",risk:"Theo % rủi ro"}],
  ["lot","Lot cố định","num","Dùng khi chọn lot cố định. Lot trong strategy không được dùng."],
  ["riskPct","% vốn rủi ro mỗi lệnh","num","EA tính lot từ khoảng cách SL và số dư."]]],
 ["Giá vào / SL / TP",[
  ["priceMode","Cách quy đổi giá","sel",{distance:"Theo khoảng cách (khuyến nghị)",absolute:"Giá tuyệt đối + chênh lệch"},"Futures GC và spot XAUUSD lệch giá nhau. Theo khoảng cách: EA lấy chênh lệch Entry→SL/TP rồi áp vào giá thị trường MT5."],
  ["offset","Chênh lệch giá (MT5 − TV)","num","Chỉ dùng khi quy đổi theo giá tuyệt đối."],
  ["tpMode","TP lấy từ","sel",{strategy:"Strategy gửi sang",rr:"Tính lại theo RR bên dưới"}],
  ["rr","RR (khi tính lại TP)","num"],
  ["beAtR","Dời SL về hòa vốn tại x R (0 = tắt)","num"]]],
 ["Giới hạn an toàn",[
  ["maxTradesDay","Số lệnh tối đa mỗi ngày (0 = không giới hạn)","num"],
  ["maxOpen","Số lệnh đang mở tối đa","num"],
  ["maxSpread","Spread tối đa (points)","num","Spread vượt mức này thì EA bỏ qua tín hiệu."],
  ["slippage","Slippage tối đa (points)","num"],
  ["maxLot","Lot tối đa mỗi lệnh","num","Trần cứng, áp cho cả lệnh tay lẫn tín hiệu TradingView (kể cả khi tính lot theo % rủi ro). Server còn có trần riêng HARD_MAX_LOT."],
  ["maxDev","Lệch giá tối đa so với giá lúc bấm (đơn vị giá, 0 = tắt)","num","Lệnh tay: nếu giá thật trên MT5 đã chạy xa giá bạn thấy lúc bấm hơn mức này thì EA từ chối. Ví dụ vàng: 0.5 = 50 cent."],
  ["expirySec","Tín hiệu hết hạn sau (giây)","num","EA bỏ tín hiệu cũ hơn mức này, tránh vào lệnh trễ khi mất kết nối."],
  ["pendingMin","Lệnh chờ tự hết hạn sau (phút, 0 = không)","num","Áp dụng cho lệnh Limit/Stop. Lệnh chờ chưa khớp sẽ tự bị hủy khi hết hạn."],
  ["magic","Magic number","num"]]],
 ["Giờ giao dịch (giờ server MT5)",[
  ["useSession","Chỉ vào lệnh trong khung giờ","bool"],
  ["sessFrom","Từ","time"],["sessTo","Đến","time"]]]
];
let cfg=Object.assign({},DEF);
function buildForm(){
  $("form").innerHTML=FIELDS.map(([title,fs])=>`<div class="card"><h2>${title}</h2>`+fs.map(([k,l,t,x,h])=>{
    const hint=(t==="sel"?h:x)||"";let c="";
    if(t==="bool")c=`<input type="checkbox" id="f_${k}">`;
    else if(t==="area")c=`<textarea id="f_${k}" rows="3" style="grid-column:1/-1"></textarea>`;
    else if(t==="sel")c=`<select id="f_${k}">${Object.entries(x).map(([v,n])=>`<option value="${v}">${n}</option>`).join("")}</select>`;
    else c=`<input id="f_${k}" type="${t==="time"?"time":"number"}" step="any">`;
    return `<div class="f"><label for="f_${k}">${l}</label>${t==="area"?"":c}${hint?`<small>${hint}</small>`:""}${t==="area"?c:""}</div>`;
  }).join("")+`</div>`).join("");
  fillForm();
}
function fillForm(){
  $("enabled").checked=!!cfg.enabled;
  FIELDS.forEach(([,fs])=>fs.forEach(([k,,t])=>{const e=$("f_"+k);t==="bool"?e.checked=!!cfg[k]:e.value=cfg[k]}));
}
function readForm(){
  cfg.enabled=$("enabled").checked;
  FIELDS.forEach(([,fs])=>fs.forEach(([k,,t])=>{const e=$("f_"+k);cfg[k]=t==="bool"?e.checked:(t==="num"?parseFloat(e.value)||0:e.value)}));
}
function normUrl(u){u=(u||"").trim().replace(/\/+$/,"");return u&&!/^https?:\/\//i.test(u)?"https://"+u:u}
C.url=normUrl(C.url);
const why=e=>e.message==="NET"?"không gọi được tới server: sai URL, bị CORS, hoặc trang đang mở trong khung xem trước bị chặn mạng (hãy tải file về và mở bằng trình duyệt)":e.message==="HTTP 401"?"sai Secret token (phải trùng TOKEN trên Cloudflare)":e.message;
async function api(method,path,body){
  let r;
  try{r=await fetch(C.url+path,{method,headers:{"Content-Type":"application/json","X-Token":C.token},body:body?JSON.stringify(body):undefined})}
  catch(e){throw new Error("NET")}
  if(!r.ok){
    let m="HTTP "+r.status;   // 401 và 409 giữ nguyên chuỗi gốc vì nơi khác so sánh đúng chuỗi này
    if(r.status!==401&&r.status!==409){try{const j=await r.json();if(j&&j.error)m+=": "+j.error}catch{}}   // hiện lý do cụ thể từ Worker (vd lot vượt maxLot)
    throw new Error(m);
  }
  return r.status===204?null:r.json();
}
/* ================= ĐƯỜNG NHANH: server local trên PC chạy MT5 (thư mục local-bridge/) =================
   Lệnh tay đi thẳng web -> server local -> EA (vài ms) thay vì web -> Cloudflare -> EA. Worker vẫn là đường dự phòng và nơi lưu Journal. */
function normLocal(u){u=(u||"").trim().replace(/\/+$/,"");return u&&!/^https?:\/\//i.test(u)?(/^(127\.0\.0\.1|localhost)/i.test(u)?"http://":"https://")+u:u}
C.lurl=normLocal(C.lurl);
const LANE={up:false,t:0,ms:0,err:"",busy:false};
async function lapi(method,path,body,tmo){
  let r;
  try{r=await fetch(C.lurl+path,{method,headers:{"Content-Type":"application/json","X-Token":C.token},body:body?JSON.stringify(body):undefined,
    signal:tmo&&typeof AbortSignal.timeout==="function"?AbortSignal.timeout(tmo):undefined})}
  catch(e){throw new Error("NET")}
  if(!r.ok){
    let j=null;try{j=await r.json()}catch{}
    const e=new Error("HTTP "+r.status+(r.status!==401&&r.status!==409&&j&&j.error?": "+j.error:""));   /* giống api(): 401 và 409 giữ nguyên chuỗi gốc */
    e.status=r.status;e.code=j&&j.code;throw e;
  }
  return r.status===204?null:r.json();
}
async function laneCheck(){
  if(!C.lurl||!C.token){LANE.up=false;LANE.err="chưa nhập địa chỉ server local";return}
  if(LANE.busy)return;LANE.busy=true;
  const t0=performance.now();
  try{const h=await lapi("GET","/api/health",null,1500);LANE.up=!!h.eaUp;LANE.ms=Math.round(performance.now()-t0);LANE.err=h.eaUp?"":"EA đường nhanh (InpFastOnly) chưa chạy"}
  catch(e){LANE.up=false;LANE.err=why(e)}
  LANE.t=Date.now();LANE.busy=false;
}
setInterval(laneCheck,2000);laneCheck();
const laneOn=()=>!!C.lurl&&LANE.up&&Date.now()-LANE.t<6000;
/* Gửi lệnh đóng / sửa SL-TP: đường nhanh nếu đang sống. Chỉ khi server local trả 503 (chắc chắn CHƯA nhận lệnh) mới chuyển sang Worker;
   lỗi mạng giữa chừng thì báo lỗi, không tự gửi lại vì lệnh có thể đã vào hàng đợi (tránh đóng/sửa hai lần). */
async function viaLane(method,path,body){
  if(laneOn()){
    try{return{r:await lapi(method,path,body,8000),fn:lapi}}
    catch(e){if(!(e.status===503&&(e.code==="ea_down"||e.code==="cfg_stale")))throw e}
  }
  return{r:await api(method,path,body),fn:api};
}
async function loadCfg(){
  if(!C.url||!C.token){$("eaMsg").textContent="Chưa nhập API ở mục Kết nối.";return}
  try{const s=await api("GET","/api/settings");cfg=Object.assign({},DEF,s);cfgOk=true;fillForm();$("eaMsg").textContent="Đã tải cài đặt từ server."}
  catch(e){$("eaMsg").textContent="Không tải được cài đặt: "+why(e)}
}
let cfgOk=false; // chỉ cho lưu sau khi đã tải được cài đặt thật, tránh ghi đè bằng giá trị mặc định
async function saveCfg(){
  if(!C.url||!C.token){$("eaMsg").textContent="Chưa nhập API ở mục Kết nối.";return}
  if(!cfgOk){fillForm();$("eaMsg").textContent="Chưa tải được cài đặt hiện tại từ server nên chưa cho lưu (tránh ghi đè bằng mặc định). Kiểm tra mục Kết nối.";return}
  readForm();
  try{await api("PUT","/api/settings",cfg);$("eaMsg").textContent="Đã lưu lên server. EA sẽ nhận ở lần kiểm tra tới.";
    if(C.lurl)lapi("POST","/api/refresh",null,3000).catch(()=>{})}   /* báo server local lấy cài đặt mới ngay, khỏi chờ nhịp 3 giây */
  catch(e){$("eaMsg").textContent="Lưu thất bại: "+why(e)}
}
$("save").onclick=saveCfg;
$("enabled").onchange=saveCfg;
$("reset").onclick=()=>{cfg=Object.assign({},DEF);fillForm();$("eaMsg").textContent="Đã đưa về mặc định. Bấm Lưu để áp dụng."};

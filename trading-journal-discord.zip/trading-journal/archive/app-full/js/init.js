buildTfs();buildForm();applyTz();clk();setTheme();setSide();show("chart");loadM1();loadCfg();
setInterval(poll,1000);setInterval(clk,1000);
requestAnimationFrame(()=>requestAnimationFrame(()=>document.body.classList.remove("nt")));

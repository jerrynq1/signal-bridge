/* ================= MÚI GIỜ =================
   Nến lưu theo giờ server MT5 (giây). Trục thời gian và đồng hồ quy đổi sang múi giờ người dùng chọn bằng Intl (tên IANA),
   nên tự đổi theo giờ mùa (DST) của từng nước. Giờ server MT5 cũng có DST, nên có 3 kiểu: theo mùa Mỹ, theo mùa châu Âu, hoặc cố định. */
const p2=n=>String(n).padStart(2,"0");
let DEVZ="UTC";try{DEVZ=Intl.DateTimeFormat().resolvedOptions().timeZone||"UTC"}catch{}
let TZ=ld("tp_tz","")||DEVZ,SRVD=null,SRVL=null,SRVN=0,SRVH=[{from:0,off:7200}],SRVOK=false;
const PF={},OC={};let OCN=0;
const pf=z=>PF[z]||(PF[z]=new Intl.DateTimeFormat("en-US",{timeZone:z,hourCycle:"h23",year:"numeric",month:"numeric",day:"numeric",hour:"numeric",minute:"numeric",second:"numeric"}));
try{pf(TZ)}catch{TZ="UTC"}
function parts(z,ms){const o={};pf(z).formatToParts(new Date(ms)).forEach(x=>{if(x.type!=="literal")o[x.type]=+x.value});o.hour%=24;return o}
// độ lệch (giây) của múi giờ z so với UTC tại thời điểm ms, đã tính giờ mùa
function tzOff(z,ms){
  const k=z+"|"+Math.floor(ms/900000);let v=OC[k];if(v!==undefined)return v;
  const o=parts(z,ms);v=Math.round((Date.UTC(o.year,o.month-1,o.day,o.hour,o.minute,o.second)-Math.floor(ms/1000)*1000)/1000);
  if(++OCN>4000){for(const x in OC)delete OC[x];OCN=0}
  return OC[k]=v;
}
/* Giờ server MT5 tự dò từ giá live của EA, không cần cài đặt. Mỗi lần server đổi giờ (mùa hè/đông) được ghi lại kèm mốc thời gian
   (SRVH = [{from: giờ server, off: giây lệch UTC}]) nên nến cũ vẫn quy đổi đúng theo giờ lúc đó. */
(function(){
  let ok=false;
  try{const s=JSON.parse(ld("tp_srvh","null"));if(s&&Array.isArray(s.h)&&s.h.length&&s.h.every(x=>Number.isFinite(x.from)&&Number.isFinite(x.off))){SRVH=s.h;SRVOK=!!s.ok;ok=true}}catch{}
  if(!ok){ // chưa dò lần nào: tạm lấy theo cài đặt cũ (nếu có), nếu không thì GMT+2/+3 theo giờ mùa Mỹ
    let off=tzOff("America/New_York",Date.now())+25200;
    try{const o=JSON.parse(ld("tp_srv","null"));if(o){if(o.m==="fix")off=Math.round((+o.h||0)*3600);else if(o.m==="eet")off=tzOff("Europe/Athens",Date.now())}}catch{}
    SRVH=[{from:0,off}];
  }
})();
const srvCur=()=>SRVH[SRVH.length-1].off;
function srvAt(t){for(let i=SRVH.length-1;i>0;i--)if(t>=SRVH[i].from)return SRVH[i].off;return SRVH[0].off}
const saveSrv=()=>sv("tp_srvh",JSON.stringify({h:SRVH,ok:SRVOK}));
const toUtcMs=t=>(t-srvAt(t))*1000;
// đầu tuần giao dịch hiện tại (giờ server): server thường đổi giờ vào cuối tuần nên nến từ mốc này mới tính theo giờ mới
function chgFrom(){
  const n=m1.length;if(!n)return 0;
  for(let i=n-1,k=0;i>0&&k<9000;i--,k++)if(m1[i][0]-m1[i-1][0]>21600)return m1[i][0];
  return m1[n-1][0];
}
function commitSrv(off){
  const last=SRVH[SRVH.length-1];
  if(!SRVOK){SRVH=[{from:0,off}];SRVOK=true}          // lần dò đầu tiên: xác nhận, thay cho giá trị tạm
  else if(last.off!==off)SRVH.push({from:Math.max(chgFrom(),last.from+1),off});
  else return;
  saveSrv();if(agg.length)rebuild(false);clk();if($("tzq"))tzList();srvHint();
}
// Thời gian đưa vào chart = đồng hồ của múi giờ đã chọn (coi như UTC), để lưới trục (00:00, 03:00, 06:00...) khớp giờ người dùng.
// st (giờ server) vẫn giữ nguyên để gom nến D1/W1 đúng ranh giới của broker.
function disp(st){if(TZ==="srv")return st;const u=toUtcMs(st);return Math.round(u/1000+tzOff(TZ,u))}
const lp=t=>parts("UTC",t*1000);
const lbl=s=>"UTC"+(s<0?"-":"+")+Math.floor(Math.abs(s)/3600)+(Math.abs(s)%3600?":"+p2(Math.round(Math.abs(s)%3600/60)):"");
function tickFmt(t){if(typeof t!=="number")return null;const o=lp(t);if(C.tf<86400&&(o.hour||o.minute))return p2(o.hour)+":"+p2(o.minute);if(o.day===1)return o.month===1?String(o.year):"Th"+o.month;return String(o.day)}
function crossFmt(t){if(typeof t!=="number")return "";const o=lp(t);return p2(o.day)+"/"+p2(o.month)+"/"+String(o.year).slice(2)+(C.tf<86400?"  "+p2(o.hour)+":"+p2(o.minute):"")}
function applyTz(){allCh().forEach(x=>x.applyOptions({localization:{timeFormatter:t=>crossFmt(t)},timeScale:{tickMarkFormatter:t=>tickFmt(t)}}))}
function clk(){
  const now=Date.now(),sv_=TZ==="srv",o=sv_?parts("UTC",now+srvCur()*1000):parts(TZ,now);
  $("clkT").textContent=p2(o.hour)+":"+p2(o.minute)+":"+p2(o.second);
  $("clkZ").textContent=sv_?"Server "+lbl(srvCur()):lbl(tzOff(TZ,now));
}
const COMMON=["UTC","Asia/Ho_Chi_Minh","Asia/Bangkok","Asia/Singapore","Asia/Hong_Kong","Asia/Shanghai","Asia/Tokyo","Asia/Seoul","Asia/Kolkata","Asia/Dubai","Europe/Moscow","Europe/Istanbul","Europe/London","Europe/Paris","Europe/Berlin","America/New_York","America/Chicago","America/Los_Angeles","Australia/Sydney","Pacific/Auckland"];
let ALLZ=[];try{ALLZ=Intl.supportedValuesOf("timeZone")}catch{}
if(!ALLZ.length)ALLZ=[...COMMON];
const zname=z=>z==="srv"?"Giờ server MT5":z.replace(/_/g," ").replace("/"," · ");
function tzList(){
  const q=($("tzq").value||"").trim().toLowerCase(),now=Date.now();
  let L=q?["srv","UTC",...ALLZ].filter(z=>(z+" "+zname(z)).toLowerCase().includes(q)).slice(0,80):[...new Set(["srv",DEVZ,...COMMON])];
  if(!L.includes(TZ))L.unshift(TZ);
  $("tzl").innerHTML=L.length?L.map(z=>{let off="";try{off=lbl(z==="srv"?srvCur():tzOff(z,now))}catch{return ""}
    return `<button type="button" class="tzi${z===TZ?" on":""}" data-z="${z}"><span>${zname(z)}${z===DEVZ?" (thiết bị)":""}</span><span>${off}</span></button>`}).join(""):`<span class="msg" style="padding:6px 8px">Không tìm thấy múi giờ.</span>`;
}
function srvHint(){
  const e=$("srvHint");if(!e)return;
  e.textContent=SRVOK?"Giờ server MT5: tự dò được "+lbl(srvCur())+", tự cập nhật khi server đổi giờ mùa.":"Giờ server MT5: tạm tính "+lbl(srvCur())+", sẽ tự dò chính xác khi thị trường mở cửa.";
}
function openTz(){
  $("tzp").innerHTML=`<input id="tzq" type="search" placeholder="Tìm múi giờ (vd: Tokyo, London, New York)" aria-label="Tìm múi giờ" autocomplete="off"><div id="tzl"></div>
  <small class="msg" id="srvHint"></small>`;
  $("tzp").classList.add("on");$("clkB").setAttribute("aria-expanded","true");tzList();srvHint();
}
function closeTz(){$("tzp").classList.remove("on");$("clkB").setAttribute("aria-expanded","false")}
function tzChanged(){applyTz();clk();if(agg.length)rebuild(false);if($("tzq")){tzList();srvHint()}}
$("clkB").onclick=()=>$("tzp").classList.contains("on")?closeTz():openTz();
$("tzp").onclick=e=>{const b=e.target.closest("[data-z]");if(!b)return;TZ=b.dataset.z;sv("tp_tz",TZ);tzChanged()};
$("tzp").oninput=e=>{if(e.target.id==="tzq")tzList()};
document.addEventListener("click",e=>{if($("tzp").classList.contains("on")&&!e.composedPath().some(n=>n.id==="tzp"||n.id==="clk"))closeTz()});
document.addEventListener("keydown",e=>{if(e.key==="Escape"&&$("tzp").classList.contains("on")&&!document.querySelector(".mdl")){closeTz();$("clkB").focus()}});

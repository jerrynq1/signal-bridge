/* ================= LỆNH ĐANG MỞ =================
   1) Bảng "Lệnh đang mở" dưới chart (đóng / đóng một phần / sửa SL-TP ngay trong bảng)
   2) Line Entry / SL / TP của lệnh đang mở vẽ ngay trên chart, KÉO được để chỉnh SL/TP
   3) Chuột phải vào chart (hoặc nút "+" ở mép phải): menu Buy Limit / Sell Limit / Buy Stop / Sell Stop tại mức giá đang trỏ
      (chỉ hiện loại hợp lệ theo giá đang nằm trên hay dưới giá thị trường) + dời SL/TP của lệnh đang mở
   Dữ liệu đến từ q.positions của /api/quote (EA gửi mỗi giây). Sửa SL/TP đi qua /api/positions/modify -> EA. */
(()=>{
const cw=$("cw"),ch=$("chart"),card=$("chartCard"),vc=$("v-chart");
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const same=(a,b)=>String(a).toLowerCase()===String(b).toLowerCase();
const sg=x=>(x>0?"+":x<0?"−":"")+Math.abs(x).toFixed(2);
const sc=x=>x>0?"up":x<0?"dn":"";
let POS=[],QT=[],ACC=null,AGEMS=0,PEND={},DRAG=null,MENU=null;

/* ---------- dữ liệu ---------- */
const dgOf=sym=>{
  const q=QT.find(z=>same(z.symbol,sym));if(q&&q.dg!=null)return +q.dg;
  const p=POS.find(z=>same(z.symbol,sym));if(p&&p.dg!=null)return +p.dg;
  const s=same(sym,C.sym)?String($("bid").textContent).split(".")[1]:"";return Math.max(2,s?s.length:0)};
const tick=sym=>Math.pow(10,-dgOf(sym));
const rnd=(x,sym)=>+(+x).toFixed(dgOf(sym));
/* Giá trị 1 lot khi giá đi 1 đơn vị (theo tiền tài khoản): ưu tiên EA gửi (pv), không có thì suy ra từ lệnh đang mở cùng mã */
function pvOf(sym){
  const q=QT.find(z=>same(z.symbol,sym));if(q&&q.pv>0)return q.pv;
  for(const p of POS){const d=Math.abs(p.price-p.open)*p.volume;if(same(p.symbol,sym)&&d>0&&p.profit)return Math.abs(p.profit)/d}
  return 0}
const eSl=p=>PEND[p.ticket]?PEND[p.ticket].sl:p.sl;
const eTp=p=>PEND[p.ticket]?PEND[p.ticket].tp:p.tp;
const pnlAt=(p,price)=>{const pv=pvOf(p.symbol);return pv?(p.side==="buy"?1:-1)*(price-p.open)*p.volume*pv:null};
const chk=(p,k,x)=>{if(!(x>0))return"";const b=p.side==="buy",c=p.price;
  return k==="sl"?((b?x<c:x>c)?"":(b?"SL phải nằm dưới giá hiện tại":"SL phải nằm trên giá hiện tại")):((b?x>c:x<c)?"":(b?"TP phải nằm trên giá hiện tại":"TP phải nằm dưới giá hiện tại"))};

window.posOnQuote=q=>{
  try{
    POS=(q.positions||[]).map(p=>({...p,ticket:String(p.ticket)}));QT=q.quotes||[];ACC=q.account||null;
    AGEMS=q.receivedAt?Date.now()-q.receivedAt:0;
    for(const t in PEND){const p=POS.find(z=>z.ticket===t),e=PEND[t];
      if(!p||Date.now()-e.t>25000){delete PEND[t];continue}
      const tol=tick(p.symbol)/2+1e-12;if(Math.abs(p.sl-e.sl)<=tol&&Math.abs(p.tp-e.tp)<=tol)delete PEND[t]}
    renderDock()}catch(e){console.error("positions",e)}};

/* ---------- gửi lệnh về EA ---------- */
async function waitCmd(path,id,okMsg,tmo,fn){
  fn=fn||api;const t0=Date.now();
  for(;;){await sleep(fn===api?500:60);
    const s=await fn("GET",path+encodeURIComponent(id));
    if(s.status==="done")return{ok:true,note:s.note};
    if(s.status==="rejected")return{ok:false,note:s.note};
    if(s.status==="expired")return{ok:false,note:s.note,expired:true};
    if(s.status==="unknown")return{ok:false,note:s.note||"Chưa có xác nhận từ EA, hãy kiểm tra MT5.",unknown:true};
    if(Date.now()-t0>tmo)return{ok:false,note:"Chưa có phản hồi từ EA. Hãy cập nhật EA bản mới và kiểm tra EA đang chạy.",timeout:true}}}
async function sendModify(p,sl,tp){
  PEND[p.ticket]={sl,tp,t:Date.now()};dirty2();
  try{
    const q=await viaLane("POST","/api/positions/modify",{ticket:p.ticket,sl,tp});
    const s=await waitCmd("/api/modifies?id=",q.r.id,"",20000,q.fn);
    if(s.ok)toast("Đã cập nhật SL/TP · #"+p.ticket,"ok",2500);
    else if(s.expired&&/thay/.test(s.note||"")){}                       // bị lệnh sửa mới hơn thay thế: bỏ qua
    else{delete PEND[p.ticket];toast("EA từ chối: "+s.note,"bad",7000)}
  }catch(e){delete PEND[p.ticket];toast("Không gửi được: "+why(e),"bad",6000)}}
async function closeReq(p,vol){
  try{
    const q=await viaLane("POST","/api/positions/close",{ticket:p.ticket,volume:vol||0});
    const s=await waitCmd("/api/commands?id=",q.r.id,"",20000,q.fn);
    return s}catch(e){return{ok:false,note:e.message==="HTTP 409"?"Đã có lệnh đóng đang chờ cho vị thế này":why(e)}}}

/* ---------- hộp thoại đóng lệnh ---------- */
function modal(html,onReady){
  return new Promise(res=>{
    const o=document.createElement("div"),back=document.activeElement;o.className="mdl";o.setAttribute("role","dialog");o.setAttribute("aria-modal","true");
    o.innerHTML='<div class="box">'+html+'</div>';
    const kd=e=>{if(e.key==="Escape"){e.preventDefault();done(null)}};
    const done=v=>{o.remove();document.removeEventListener("keydown",kd,true);if(back&&back.isConnected&&back.focus)back.focus();res(v)};
    document.addEventListener("keydown",kd,true);
    o.onclick=e=>{if(e.target===o)return done(null);const b=e.target.closest("[data-r]");if(b)done(b.dataset.r)};
    document.body.append(o);onReady&&onReady(o);});}
async function doClose(p){
  const r=await modalClose(p);
  if(r==null)return;
  toast("Đang gửi lệnh đóng…","",0);
  const s=await closeReq(p,r>=p.volume-1e-9?0:r);
  toast(s.ok?s.note||"Đã đóng lệnh":"EA từ chối: "+s.note,s.ok?"ok":"bad",s.ok?4000:8000);}
function modalClose(p){
  const buy=p.side==="buy";let vol=p.volume;
  return modal('<header><h3>Đóng lệnh</h3></header><div class="bd">'+
    '<p class="cl-t"><span class="sd '+p.side+'">'+p.side.toUpperCase()+'</span> '+esc(p.volume)+' lot '+esc(p.symbol)+' <small>#'+esc(p.ticket)+'</small></p>'+
    '<p class="cl-p '+sc(p.profit)+'">P/L hiện tại '+sg(p.profit)+'</p>'+
    '<label class="msg" for="clV">Lot cần đóng</label><input id="clV" type="number" step="0.01" min="0.01" max="'+p.volume+'" value="'+p.volume+'">'+
    '<div class="cl-ch"><button type="button" class="btn ghost sm" data-p="25">25%</button><button type="button" class="btn ghost sm" data-p="50">50%</button><button type="button" class="btn ghost sm" data-p="75">75%</button><button type="button" class="btn ghost sm" data-p="100">100%</button></div>'+
    '<p class="msg" id="clM" style="margin:8px 0 0">Đóng hết lệnh này.</p></div>'+
    '<footer><span style="flex:1"></span><button class="btn ghost sm" type="button" data-r="">Hủy</button><button class="btn sm" type="button" data-r="ok" id="clOk">Đóng lệnh</button></footer>',
    o=>{const v=o.querySelector("#clV"),m=o.querySelector("#clM"),ok=o.querySelector("#clOk");
      const upd=()=>{const x=parseFloat(v.value);ok.disabled=!(x>0&&x<=p.volume+1e-9);m.textContent=x>=p.volume-1e-9?"Đóng hết lệnh này.":"Đóng một phần, phần còn lại vẫn chạy với SL/TP hiện tại."};
      o.querySelector(".cl-ch").onclick=e=>{const b=e.target.closest("[data-p]");if(!b)return;const pc=+b.dataset.p;v.value=pc===100?p.volume:(Math.floor(p.volume*pc)/100).toFixed(2);upd()};
      v.oninput=upd;v.onkeydown=e=>{if(e.key==="Enter"&&!ok.disabled)ok.click()};
      ok.style.background="linear-gradient(135deg,#ff5c8a,#d6336c)";ok.style.color="#fff";
      o.addEventListener("click",e=>{if(e.target.closest("#clOk"))vol=parseFloat(v.value)},true);v.focus();v.select()}
  ).then(r=>r==="ok"?vol:null);}
async function closeAll(){
  if(!POS.length)return;
  const tot=POS.reduce((a,p)=>a+p.profit,0);
  const r=await modal('<header><h3>Đóng tất cả lệnh</h3></header><div class="bd"><p style="font-size:17px;font-weight:700;margin:6px 0 10px">Đóng '+POS.length+' lệnh đang mở?</p><p class="cl-p '+sc(tot)+'">Tổng P/L hiện tại '+sg(tot)+'</p></div><footer><span style="flex:1"></span><button class="btn ghost sm" type="button" data-r="">Hủy</button><button class="btn sm" type="button" data-r="ok" id="caOk" style="background:linear-gradient(135deg,#ff5c8a,#d6336c)">Đóng tất cả</button></footer>',o=>o.querySelector("#caOk").focus());
  if(r!=="ok")return;
  toast("Đang gửi lệnh đóng…","",0);
  const list=POS.slice(),res=await Promise.all(list.map(p=>closeReq(p,0)));
  const n=res.filter(x=>x.ok).length;
  toast(n===list.length?"Đã đóng "+n+" lệnh":"Đóng được "+n+"/"+list.length+" lệnh. "+(res.find(x=>!x.ok)||{}).note,n===list.length?"ok":"bad",8000);}

/* ---------- LINE TRÊN CHART ---------- */
const ov=document.createElement("div");ov.id="pl";ch.appendChild(ov);
const add=document.createElement("button");add.id="plAdd";add.type="button";add.setAttribute("aria-label","Đặt SL/TP tại mức giá này");add.innerHTML='<b>+</b><span></span>';ov.appendChild(add);
const G=new Map();
const TAG_E='<i class="pl-ln"></i><div class="pl-tag"><span class="pl-sd"></span><span class="pl-v"></span><span class="pl-pnl"></span><button type="button" class="pl-c" data-a="sl">+SL</button><button type="button" class="pl-c" data-a="tp">+TP</button><button type="button" class="pl-x" data-a="close" title="Đóng lệnh" aria-label="Đóng lệnh">×</button></div><span class="pl-ax"></span>';
const TAG_L='<i class="pl-ln"></i><span class="pl-hit"></span><div class="pl-tag"><span class="pl-gr"></span><span class="pl-k"></span><span class="pl-pnl"></span><span class="pl-w"></span><button type="button" class="pl-x" data-a="rm" title="Gỡ line này" aria-label="Gỡ line này">×</button></div><span class="pl-ax"></span>';
function T(g,s,txt){const e=g._e[s]||(g._e[s]=g.querySelector(s));if(e.textContent!==txt)e.textContent=txt;return e}
function mkRow(it){const g=document.createElement("div");g._e={};g.dataset.k=it.k;g.innerHTML=it.t==="e"?TAG_E:TAG_L;ov.insertBefore(g,add);return g}
const dirty2=()=>{};
function model(){
  const out=[];
  for(const p of POS){
    if(!same(p.symbol,C.sym))continue;
    out.push({k:"e:"+p.ticket,t:"e",p,price:p.open});
    const sl=eSl(p),tp=eTp(p),pd=!!PEND[p.ticket];
    if(sl>0)out.push({k:"sl:"+p.ticket,t:"sl",p,price:sl,pd});
    if(tp>0)out.push({k:"tp:"+p.ticket,t:"tp",p,price:tp,pd});}
  return out}
function frame(){
  requestAnimationFrame(frame);
  if(!vc.classList.contains("on")||!agg.length){if(ov.style.display!=="none")ov.style.display="none";return}
  ov.style.display="";
  let aw=60,H=ch.clientHeight-28;try{aw=chart.priceScale("right").width();H=plot()[1]}catch(e){}
  ov.style.setProperty("--aw",aw+"px");
  const items=model(),seen=new Set();
  for(const it of items){
    if(DRAG&&DRAG.k===it.k)it.price=DRAG.price;
    const y0=cs.priceToCoordinate(it.price);if(y0==null)continue;
    let g=G.get(it.k);if(!g){g=mkRow(it);G.set(it.k,g)}
    seen.add(it.k);
    const off=y0<8?"up":y0>H-8?"dn":"",y=Math.max(8,Math.min(H-8,y0));
    g.style.transform="translateY("+y+"px)";
    const sym=it.p?it.p.symbol:C.sym,dg=dgOf(sym),p=it.p;
    let cls,pnl=null,pnlTxt="",warn="",kTxt="",drag=false;
    if(it.t==="e"){
      cls="en";T(g,".pl-sd",p.side.toUpperCase()).className="pl-sd "+p.side;T(g,".pl-v",String(p.volume));
      pnlTxt=sg(p.profit);const pc=g.querySelector(".pl-pnl");pc.className="pl-pnl "+sc(p.profit);
      g.querySelectorAll(".pl-c").forEach(b=>{const k=b.dataset.a,has=(k==="sl"?eSl(p):eTp(p))>0;if(b.hidden!==has)b.hidden=has});
      T(g,".pl-pnl",pnlTxt);
    }else{
      const isSl=it.t==="sl";
      cls=(isSl?"sl":"tp")+" drg";drag=true;
      kTxt=isSl?"SL":"TP";
      if(p){pnl=pnlAt(p,it.price);const e=chk(p,isSl?"sl":"tp",it.price);if(e)warn="sai phía"}
      if(pnl!=null)pnlTxt=sg(pnl);
      else if(p&&!pnlTxt)pnlTxt="Δ "+Math.abs(it.price-p.open).toFixed(dg);
      T(g,".pl-k",kTxt);T(g,".pl-pnl",pnlTxt).className="pl-pnl "+(pnl!=null?sc(pnl):"");T(g,".pl-w",warn?"· "+warn:"");
      if(it.pd)cls+=" pd";if(warn)cls+=" bad"}
    if(off)cls+=" off";
    if(DRAG&&DRAG.k===it.k)cls+=" mv";
    cls="pl-g "+cls;if(g.className!==cls)g.className=cls;
    T(g,".pl-ax",(off==="up"?"▲ ":off==="dn"?"▼ ":"")+it.price.toFixed(dg));
  }
  for(const[k,g]of G)if(!seen.has(k)){g.remove();G.delete(k)}}
requestAnimationFrame(frame);

/* kéo line: bắt ở pha capture trên #cw để chart/vẽ hình không giành mất sự kiện */
cw.addEventListener("pointerdown",e=>{
  const g=e.target.closest&&e.target.closest(".pl-g");
  if(!g||e.button||!ov.contains(g))return;
  e.stopPropagation();
  if(e.target.closest("button"))return;
  if(!g.classList.contains("drg")||g.classList.contains("off"))return;
  e.preventDefault();
  const k=g.dataset.k,it=model().find(z=>z.k===k);if(!it)return;
  DRAG={k,price:it.price,p:it.p,t:it.t,y0:e.clientY,moved:false,id:e.pointerId,orig:it.price};
  try{g.setPointerCapture(e.pointerId)}catch(x){}
},true);
window.addEventListener("pointermove",e=>{
  if(!DRAG||e.pointerId!==DRAG.id)return;
  if(!DRAG.moved&&Math.abs(e.clientY-DRAG.y0)<3)return;
  DRAG.moved=true;
  const r=ch.getBoundingClientRect(),pr=cs.coordinateToPrice(e.clientY-r.top);if(pr==null)return;
  const sym=DRAG.p?DRAG.p.symbol:C.sym;DRAG.price=Math.max(tick(sym),rnd(pr,sym));
});
function endDrag(cancel){
  const D=DRAG;if(!D)return;DRAG=null;
  if(!D.moved)return;
  if(cancel)return;
  if(!D.p)return;
  const k=D.t==="sl"?"sl":"tp",err=chk(D.p,k,D.price);
  if(err){toast(err,"bad",4000);return}
  if(Math.abs(D.price-D.orig)<tick(D.p.symbol)/2)return;
  sendModify(D.p,k==="sl"?D.price:eSl(D.p),k==="tp"?D.price:eTp(D.p));}
window.addEventListener("pointerup",e=>{if(DRAG&&e.pointerId===DRAG.id)endDrag(false)});
window.addEventListener("pointercancel",e=>{if(DRAG&&e.pointerId===DRAG.id)endDrag(true)});
document.addEventListener("keydown",e=>{if(e.key==="Escape"){if(DRAG)endDrag(true);closeMenu()}});

/* nút trên tag: +SL / +TP / đóng / gỡ */
function defDist(p){
  const a=agg.slice(-30);let s=0;for(const b of a)s+=b.high-b.low;
  return Math.max(a.length?s/a.length*2:0,tick(p.symbol)*30)}
ov.addEventListener("click",e=>{
  const b=e.target.closest("button[data-a]");if(!b||b===add)return;
  const g=b.closest(".pl-g"),k=g.dataset.k,a=b.dataset.a,tk=k.split(":")[1],p=POS.find(z=>z.ticket===tk);
  if(a==="close"&&p)doClose(p);
  else if((a==="sl"||a==="tp")&&p){
    const d=defDist(p),buy=p.side==="buy",x=rnd(a==="sl"?(buy?p.price-d:p.price+d):(buy?p.price+d:p.price-d),p.symbol);
    sendModify(p,a==="sl"?x:eSl(p),a==="tp"?x:eTp(p));toast((a==="sl"?"Đã đặt SL":"Đã đặt TP")+" tại "+x+". Kéo line để chỉnh.","",3500)}
  else if(a==="rm"&&p){const isSl=k.startsWith("sl:");sendModify(p,isSl?0:eSl(p),isSl?eTp(p):0)}});

/* nút "+" ở mép phải chart + menu đặt SL/TP tại mức giá đang trỏ */
let addY=0;
cw.addEventListener("pointermove",e=>{
  if(e.pointerType!=="mouse"||DRAG||ch.classList.contains("dwa")||!agg.length||MENU){add.style.display="";return}
  if(e.target.closest&&e.target.closest("#plAdd"))return;
  const r=ch.getBoundingClientRect(),x=e.clientX-r.left,y=e.clientY-r.top;let aw=60,ph=r.height-28;try{aw=chart.priceScale("right").width();ph=plot()[1]}catch(z){}
  const pw=r.width-aw,over=e.target.closest&&e.target.closest(".pl-g");
  if(x>pw-150&&x<pw&&y>10&&y<ph-10&&!over){
    const pr=cs.coordinateToPrice(y);if(pr==null){add.style.display="";return}
    addY=y;add.querySelector("span").textContent=rnd(pr,C.sym).toFixed(dgOf(C.sym));
    add.style.transform="translate("+(pw-104)+"px,"+(y-12)+"px)";add.style.display="flex"}
  else add.style.display="";});
cw.addEventListener("pointerleave",()=>{if(!MENU)add.style.display=""});
function closeMenu(){if(MENU){MENU.remove();MENU=null;add.style.display=""}}
/* Menu đặt lệnh chờ / dời SL-TP tại mức giá P. Dùng chung cho chuột phải và nút "+".
   Trên giá thị trường: Sell Limit + Buy Stop. Dưới giá thị trường: Buy Limit + Sell Stop. */
function openMenu(P,x,y,anchor){
  const ar=anchor?anchor.getBoundingClientRect():null;   // đo nút "+" trước khi ẩn nó, nếu không menu bị trôi lên góc trái
  closeMenu();add.style.display="";
  const dg=dgOf(C.sym),bid=parseFloat($("bid").textContent),ask=parseFloat($("ask").textContent),lot=$("oLot").value.trim()||"0",m=document.createElement("div");m.id="plMenu";
  const pb=(k,lbl,c)=>'<button class="'+c+'" data-a="pend" data-k="'+k+'">'+lbl+" "+esc(lot)+" at "+P.toFixed(dg)+'</button>';
  let h='<div class="mh">Tại '+P.toFixed(dg)+'</div><div class="ms">Lệnh chờ</div>';
  if(!(bid>0&&ask>0))h+='<div class="mn">Chưa có giá từ EA</div>';
  else if(P>ask)h+=pb("sell_limit","Sell Limit","s")+pb("buy_stop","Buy Stop","b");
  else if(P<bid)h+=pb("buy_limit","Buy Limit","b")+pb("sell_stop","Sell Stop","s");
  else h+='<div class="mn">Giá quá sát giá hiện tại</div>';
  const mine=POS.filter(p=>same(p.symbol,C.sym)).slice(0,4);
  if(mine.length){h+='<div class="ms">Cho lệnh đang mở</div>';
    for(const p of mine)h+='<button data-a="psl" data-t="'+esc(p.ticket)+'">Dời SL · '+p.side.toUpperCase()+' '+p.volume+' <small>#'+esc(p.ticket)+'</small></button><button data-a="ptp" data-t="'+esc(p.ticket)+'">Dời TP · '+p.side.toUpperCase()+' '+p.volume+' <small>#'+esc(p.ticket)+'</small></button>'}
  m.innerHTML=h;document.body.appendChild(m);MENU=m;
  const w=m.offsetWidth,hh=m.offsetHeight;let L,T0;
  if(ar){L=ar.left-w-6;T0=ar.top-8}else{L=x+2;T0=y+2}
  m.style.left=Math.max(8,Math.min(innerWidth-w-8,L))+"px";m.style.top=Math.max(8,Math.min(innerHeight-hh-8,T0))+"px";
  m.onclick=ev=>{
    const b=ev.target.closest("button[data-a]");if(!b)return;const a=b.dataset.a;closeMenu();
    if(a==="pend")placePending(b.dataset.k,P);
    else{const p=POS.find(z=>z.ticket===b.dataset.t);if(!p)return;const k=a==="psl"?"sl":"tp",err=chk(p,k,P);
      if(err){toast(err,"bad",4000);return}
      sendModify(p,k==="sl"?P:eSl(p),k==="tp"?P:eTp(p))}};
}
add.addEventListener("click",e=>{
  e.stopPropagation();const pr=cs.coordinateToPrice(addY);if(pr==null)return;
  openMenu(rnd(pr,C.sym),0,0,add)});
/* chuột phải vào vùng giá của chart */
cw.addEventListener("contextmenu",e=>{
  if(!ch.contains(e.target)||e.target.closest(".pl-g,#plAdd,#plMenu")||ch.classList.contains("dwa")||DRAG||!agg.length)return;
  const r=ch.getBoundingClientRect(),x=e.clientX-r.left,y=e.clientY-r.top;let aw=60,ph=r.height-28;try{aw=chart.priceScale("right").width();ph=plot()[1]}catch(z){}
  if(x<0||x>r.width-aw||y<0||y>ph)return;
  const pr=cs.coordinateToPrice(y);if(pr==null)return;
  e.preventDefault();
  openMenu(Math.max(tick(C.sym),rnd(pr,C.sym)),e.clientX,e.clientY)});
document.addEventListener("pointerdown",e=>{if(MENU&&!e.target.closest("#plMenu,#plAdd"))closeMenu()},true);

/* ---------- BẢNG DƯỚI CHART ---------- */
const dk=document.createElement("section");dk.id="dk";dk.className="card dk";dk.setAttribute("aria-label","Lệnh đang mở");
dk.innerHTML='<div class="dk-rs" title="Kéo để đổi chiều cao bảng"></div>'+
 '<header class="dk-h"><button type="button" class="dk-tg" aria-expanded="true" aria-label="Thu gọn bảng"><svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 8l5 5 5-5"/></svg></button>'+
 '<h2>Lệnh đang mở</h2><span class="dk-n" id="dkN">0</span><span class="dk-age" id="dkAge"></span>'+
 '<div class="dk-st"><span>Balance <b id="dkBal">–</b></span><span>Equity <b id="dkEq">–</b></span><span>Floating <b id="dkFl">–</b></span></div>'+
 '<button type="button" class="btn ghost sm" id="dkAll">Đóng tất cả</button></header>'+
 '<div class="dk-b"><table class="dkt"><thead><tr><th>Mã</th><th>Loại</th><th class="r">Lot</th><th class="r">Giá vào</th><th class="r">Giá hiện tại</th><th class="r">SL</th><th class="r">TP</th><th class="r">P/L</th><th class="r">Swap</th><th>Mở lúc</th><th></th></tr></thead><tbody id="dkB"></tbody></table><div class="dk-e" id="dkE"></div></div>';
card.after(dk);
const TR='<td class="sy"><button type="button" class="lk" data-a="go"></button></td><td><span class="sd"></span></td><td class="r" data-f="vol"></td><td class="r" data-f="open"></td><td class="r" data-f="price"></td><td class="r ed" data-f="sl" data-k="sl" title="Bấm để sửa SL"></td><td class="r ed" data-f="tp" data-k="tp" title="Bấm để sửa TP"></td><td class="r pl" data-f="pl"></td><td class="r" data-f="swap"></td><td data-f="time"></td><td class="r"><button type="button" class="btn ghost sm cx" data-a="close">Đóng</button></td>';
const body=$("dkB"),ROW=new Map();
const fmtT=t=>{const d=new Date(disp(t)*1000),z=n=>String(n).padStart(2,"0");return z(d.getUTCDate())+"/"+z(d.getUTCMonth()+1)+" "+z(d.getUTCHours())+":"+z(d.getUTCMinutes())};
function setC(tr,f,txt,cls){let c=(tr._c||(tr._c={}))[f];if(!c)c=tr._c[f]=tr.querySelector('[data-f="'+f+'"]');if(c.dataset.ed==="1")return;if(c.textContent!==txt)c.textContent=txt;if(cls!=null&&c.dataset.cl!==cls){c.dataset.cl=cls;c.className=c.className.replace(/\b(up|dn|pd)\b/g,"").trim()+(cls?" "+cls:"")}}
function renderDock(){
  const n=POS.length,cur=ACC&&ACC.ccy?" "+ACC.ccy:"";
  $("dkN").textContent=n;
  $("dkBal").textContent=ACC?(+ACC.balance).toFixed(2)+cur:"–";
  $("dkEq").textContent=ACC?(+ACC.equity).toFixed(2)+cur:"–";
  const fl=POS.reduce((a,p)=>a+p.profit,0),f=$("dkFl");f.textContent=n?sg(fl)+cur:"0.00"+cur;f.className=sc(fl);
  const age=$("dkAge");age.textContent=AGEMS>15000?"Dữ liệu EA cũ "+Math.round(AGEMS/1000)+" giây":"";age.hidden=AGEMS<=15000;
  $("dkAll").disabled=!n;$("dkE").hidden=n>0;
  $("dkE").textContent=C.url&&C.token?"Chưa có lệnh đang mở. Khi có lệnh, line Entry / SL / TP hiện trên chart và kéo SL/TP được trực tiếp.":"Chưa nhập API ở mục Kết nối.";
  const order=POS.slice().sort((a,b)=>b.time-a.time),keep=new Set();let prev=null;
  for(const p of order){
    keep.add(p.ticket);let tr=ROW.get(p.ticket);
    if(!tr){tr=document.createElement("tr");tr.dataset.t=p.ticket;tr.innerHTML=TR;ROW.set(p.ticket,tr)}
    const dg=dgOf(p.symbol),sl=eSl(p),tp=eTp(p),pd=PEND[p.ticket]?"pd":"";
    tr.className=p.side;
    const sy=tr.querySelector(".lk");if(sy.textContent!==p.symbol)sy.textContent=p.symbol;
    const sd=tr.querySelector(".sd");if(sd.textContent!==p.side.toUpperCase()){sd.textContent=p.side.toUpperCase();sd.className="sd "+p.side}
    setC(tr,"vol",String(p.volume));setC(tr,"open",p.open.toFixed(dg));setC(tr,"price",p.price.toFixed(dg));
    setC(tr,"sl",sl>0?sl.toFixed(dg):"—",pd);setC(tr,"tp",tp>0?tp.toFixed(dg):"—",pd);
    setC(tr,"pl",sg(p.profit),sc(p.profit));setC(tr,"swap",p.swap?p.swap.toFixed(2):"0.00");setC(tr,"time",fmtT(p.time));
    const at=prev?prev.nextSibling:body.firstChild;if(tr!==at)body.insertBefore(tr,at);prev=tr}
  for(const[t,tr]of ROW)if(!keep.has(t)){tr.remove();ROW.delete(t)}}
body.addEventListener("click",e=>{
  const tr=e.target.closest("tr");if(!tr)return;const p=POS.find(z=>z.ticket===tr.dataset.t);if(!p)return;
  const b=e.target.closest("button[data-a]");
  if(b){if(b.dataset.a==="close")doClose(p);else if(b.dataset.a==="go"){$("sym").value=p.symbol;$("sym").onchange()}return}
  const td=e.target.closest("td.ed");if(td)editCell(td,p)});
function editCell(td,p){
  if(td.dataset.ed==="1")return;const k=td.dataset.k,v=k==="sl"?eSl(p):eTp(p),dg=dgOf(p.symbol);
  td.dataset.ed="1";td.textContent="";
  const i=document.createElement("input");i.type="number";i.step="any";i.min="0";i.value=v>0?v.toFixed(dg):"";i.placeholder="0 = gỡ";i.setAttribute("aria-label",k==="sl"?"SL mới":"TP mới");
  td.append(i);i.focus();i.select();
  let fin=false;const end=ok=>{if(fin)return;fin=true;const s=i.value.trim();td.dataset.ed="";i.remove();td.textContent="";td.dataset.cl="";renderDock();
    if(!ok)return;const x=s===""?0:parseFloat(s);if(!(x>=0)){toast("Giá không hợp lệ","bad",3000);return}
    const err=chk(p,k,x);if(err){toast(err,"bad",4000);return}
    if(Math.abs(x-v)<tick(p.symbol)/2)return;sendModify(p,k==="sl"?x:eSl(p),k==="tp"?x:eTp(p))};
  i.onkeydown=e=>{if(e.key==="Enter"){e.preventDefault();end(true)}else if(e.key==="Escape"){e.stopPropagation();end(false)}};
  i.onblur=()=>end(false);}
$("dkAll").onclick=closeAll;

/* thu gọn + đổi chiều cao */
let dkH=Math.max(130,Math.min(+ld("tp_dkh",210)||210,640)),dkC=ld("tp_dkc","")==="1";
function layout(){
  dk.classList.toggle("cl",dkC);dk.style.setProperty("--dkh",dkH+"px");
  const t=dk.querySelector(".dk-tg");t.setAttribute("aria-expanded",String(!dkC));t.setAttribute("aria-label",dkC?"Mở rộng bảng":"Thu gọn bảng");
  vc.style.setProperty("--dk",((dkC?46:dkH)+14)+"px")}
layout();
dk.querySelector(".dk-tg").onclick=()=>{dkC=!dkC;sv("tp_dkc",dkC?"1":"");layout()};
dk.querySelector(".dk-h").addEventListener("dblclick",e=>{if(e.target.closest("button,b"))return;dkC=!dkC;sv("tp_dkc",dkC?"1":"");layout()});
dk.querySelector(".dk-rs").addEventListener("pointerdown",e=>{
  if(dkC)return;e.preventDefault();const y0=e.clientY,h0=dkH,el=e.currentTarget;el.setPointerCapture(e.pointerId);el.classList.add("on");
  const mv=ev=>{dkH=Math.max(130,Math.min(h0+(y0-ev.clientY),Math.round(innerHeight*.6)));layout()};
  const up=()=>{el.classList.remove("on");el.removeEventListener("pointermove",mv);el.removeEventListener("pointerup",up);el.removeEventListener("pointercancel",up);sv("tp_dkh",dkH)};
  el.addEventListener("pointermove",mv);el.addEventListener("pointerup",up);el.addEventListener("pointercancel",up)});
renderDock();
})();

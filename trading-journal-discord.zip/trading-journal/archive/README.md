# Archive – bản đầy đủ trước khi cắt

Mọi thứ đã bị cắt khỏi bản Journal nằm ở đây, nguyên vẹn và chạy được độc lập.

```
app-full/        App giao dịch đầy đủ (Chart, Indicator, Màu nến, EA Setting, Journal, Analytic, Flex Card, Kết nối)
  index.html, css/, js/, img/
  worker.js              Worker đầy đủ (tín hiệu, lệnh tay, nến, footprint, R2...)
  SignalBridge 2.mq5     EA đầy đủ (nhận tín hiệu, vào lệnh, nến M1, footprint...)
landing-full/    Trang chủ cũ (giới thiệu Footprint, Big Trade, Volume Profile...), login.html, register.html
```

Mở thử: chạy `python3 -m http.server -d archive/app-full` rồi vào `http://localhost:8000`. Cần mạng để tải thư viện chart từ jsDelivr.

Muốn đưa tính năng nào quay lại app hiện tại thì chép file JS tương ứng từ `app-full/js/` sang `app/js/`, thêm thẻ `<script>` và các `<section>` view tương ứng từ `app-full/index.html`. Phần CSS của chart nằm trong `app-full/css/style.css` (đã bị bỏ khỏi `app/css/style.css`).
